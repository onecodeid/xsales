// State
//  data ...
// Mutations
//
//
// Actions
import login from "./modules/login.js"

export const store = new Vuex.Store({
    state : {
        dialog_delete: false
    },

    mutations : {
        set_dialog_delete (state, v) {
            state.dialog_delete = v
        }
    },

    modules : {
        login: login
    }
});
