<template>
    <v-card>
        <v-card-title primary-title class="pb-0 pt-2">
            <v-layout row wrap>
                <v-flex xs9>
                    <h3 class="display-1 font-weight-light zalfa-text-title">
                        <span class="grey--text font-weight-thin headline">TRANSAKSI BARU</span> » METODE PEMBAYARAN</h3>
                </v-flex>
                <v-flex xs3 class="text-xs-right">
                    <v-btn color="default" class="btn-icon ma-0" @click="back">
                        <v-icon>undo</v-icon> &nbsp; KEMBALI
                    </v-btn>

                    <v-btn color="primary" class="btn-icon ma-0 mr-4" @click="save">
                        <v-icon>save</v-icon> &nbsp; SIMPAN
                    </v-btn>
                </v-flex>
            </v-layout>
            
        </v-card-title>
        <v-card-text class="pb-0 pt-2">
            
            <v-divider></v-divider>
            
            <v-radio-group v-model="selected_payment_id">
                <v-card v-for="(p, i) in payments" v-bind:key="i" class="mb-2">
                    <v-card-title class="cyan white--text">
                        <v-radio :label="p.M_PaymentTypeName" :value="p.M_PaymentTypeID" dark color="orange">
                            <template slot="label">
                                <h3 class="subheading">{{ p.M_PaymentTypeName }}</h3>
                            </template>
                        </v-radio>
                        <!-- <h3 class="subheading">{{ p.M_PaymentTypeName }}</h3> -->
                    </v-card-title>
                    <v-card-text>
                        <v-list two-line v-show="p.M_PaymentTypeCode == 'TRANSFER'" class="layout row wrap">

                            <!-- TRANSFER MANUAL -->
                            <template v-for="(item, index) in accounts">
                                <v-list-tile
                                :key="item.account_id"
                                avatar
                                @click=""
                                class="flex xs6"
                                >
                                    <v-list-tile-avatar class="mr-3">
                                        <v-img :src="'../'+item.bank_logo" width="96" height="48"></v-img>
                                    </v-list-tile-avatar>

                                    <v-list-tile-content>
                                        <v-list-tile-title v-html="item.account_name"></v-list-tile-title>
                                        <v-list-tile-sub-title v-html="item.account_name"></v-list-tile-sub-title>
                                    </v-list-tile-content>
                                </v-list-tile>
                            </template>
                        </v-list>
                        
                    </v-card-text>
                </v-card>
            </v-radio-group>
            

            
        </v-card-text>

        <v-card-actions>
            <v-layout row wrap>
                <v-flex xs8>
                    <v-layout row wrap>
                        <v-flex xs2 pl-2 pr-5>
                            
                        </v-flex>

                        <v-flex xs3 pr-2>
                            
                        </v-flex>

                        <v-flex xs3 pr-0>
                            
                        </v-flex>
                    </v-layout>

                    <v-layout row wrap mt-4>
                        
                    </v-layout>
                    <v-layout row wrap mt-1>
                        
                    </v-layout>
                </v-flex>

                <v-flex xs4>
                    <v-layout row wrap>
                        <v-flex xs6 class="text-xs-right pr-3">
                            <h3>Total</h3>
                        </v-flex>
                        <v-flex xs6 class="text-xs-right pr-3">
                            <h3>{{ one_money(total_price) }}</h3>
                        </v-flex>
                    </v-layout>

                    <v-layout row wrap class="mt-1">
                        <v-flex xs6 class="text-xs-right pr-3">
                            Estimasi Biaya Pengiriman
                        </v-flex>
                        <v-flex xs6 class="text-xs-right pr-3">
                            {{ one_money(courier_cost) }}
                        </v-flex>
                    </v-layout>
                    
                    <v-layout row wrap class="mt-1">
                        <v-flex xs6 class="text-xs-right pr-3">
                            <h3>Grand Total</h3>
                        </v-flex>
                        <v-flex xs6 class="text-xs-right pr-3">
                            <h3>{{ one_money(grand_total_price) }}</h3>
                        </v-flex>
                    </v-layout>
                </v-flex>
                
            </v-layout>
        </v-card-actions>
        <common-dialog-confirm
            text="APAKAH DATA YANG ANDA MASUKKAN SUDAH BENAR? Setelah konfirmasi, data akan dikirimkan ke Admin !"
            btn_cancel="Sebentar, Saya mau ubah data"
            btn_confirm="Simpan"
            :data="1"
            @confirm="do_save"
        ></common-dialog-confirm>
            
    </v-card>
</template>

<style scoped>
.zalfa-input-super-dense .v-input__control {
    min-height: 36px !important;
}

.v-avatar {
    height: 48px !important;
    width: 96px !important;
}

.v-avatar .v-image {
    border-radius: 0px;
}
</style>

<script>
module.exports = {
    components : {
        "common-dialog-confirm" : httpVueLoader("../../common/components/common-dialog-confirm.vue")
    },

    data () {
        return {
            
        }
    },

    computed : {
        details () {
            return this.$store.state.salesorder.items
        },
        
        total_price () {
            let details = this.details
            let ttl = 0
            for (let i in details)
                ttl += Math.round(details[i].item_subtotal)

            return ttl
        },

        grand_total_price () {
            return parseFloat(this.total_price) + parseFloat(this.courier_cost)
        },

        expeditions () {
            return this.$store.state.salesorder.expeditions
        },

        selected_expedition : {
            get () { return this.$store.state.salesorder.selected_expedition },
            set (v) { 
                this.$store.commit('salesorder/set_selected_expedition', v)
                this.$store.dispatch('salesorder/search_service', {})
            }
        },

        services () {
            return this.$store.state.salesorder.services
        },

        selected_service : {
            get () { return this.$store.state.salesorder.selected_service },
            set (v) { 
                this.$store.commit('salesorder/set_selected_service', v) 
                this.courier_cost = v.cost[0].value
            }
        },

        payments () {
            return this.$store.state.salesorder.payments
        },

        selected_payment : {
            get () { return this.$store.state.salesorder.selected_payment },
            set (v) { this.$store.commit('salesorder/set_selected_payment', v) }
        },

        total_weight () {
            return this.$store.state.salesorder.total_weight
        },

        courier_cost : {
            get () { return this.$store.state.salesorder.courier_cost },
            set (v) { this.$store.commit('salesorder/set_common', ['courier_cost', v]) }
        },

        ds_customers () {
            return this.$store.state.salesorder.ds_customers
        },

        selected_ds_customer : {
            get () { return this.$store.state.salesorder.selected_ds_customer },
            set (v) { this.$store.commit('salesorder/set_selected_ds_customer', v) }
        },

        search_ds_customer : {
            get () { return this.$store.state.salesorder.search_ds_customer },
            set (v) { this.$store.commit('salesorder/set_common', ['search_ds_customer', v]) }
        },

        is_dropship : {
            get () { return this.$store.state.salesorder.is_dropship },
            set (v) { this.$store.commit('salesorder/set_common', ['is_dropship', v]) }
        },

        accounts () {
            return this.$store.state.salesorder.accounts
        },

        selected_payment_id : {
            get () { return this.$store.state.salesorder.selected_payment_id },
            set (v) { this.$store.commit('salesorder/set_common', ['selected_payment_id', v]) }
        }
    },

    methods : {
        one_money (x) {
            return window.one_money(x)
        },

        select (x) {
            return
        },

        add () {
            this.$store.commit('newitem/set_common', ['dialog_items', true] )
        },

        change_qty (i, j) {
            let items = this.$store.state.salesorder.items
            items[i].item_qty = j
            items[i].item_subtotal = (items[i].item_price - items[i].item_discrp) * items[i].item_qty

            this.$store.commit('salesorder/update_items', items)
        },

        save () {
            this.$store.commit('set_dialog_confirm', true)
        },

        do_save () {
            this.$store.dispatch('salesorder/save')
        },

        thr_search: _.debounce( function () {
            this.$store.dispatch("salesorder/search_ds_customer")
        }, 700),

        back () {
            this.$store.commit('salesorder/set_common', ['selected_tab', 1])
        }
    },

    mounted () {
    },

    watch : {
        total_weight (v, o) {
            this.$store.dispatch('salesorder/search_service', {})
            let x = this.$store.state.salesorder.services
            let y = this.$store.state.salesorder.selected_service

            for (let i of x) {
                if (this.selected_service.service == i.service)
                    this.selected_service = i
            }
                
        },

        search_ds_customer(val, old) {
            if (val == null || typeof val == 'undefined') val = ""
            if (val == old ) return
            if (this.$store.state.salesorder.search_status == 1 ) return  
            this.$store.commit("salesorder/set_common", ['search_ds_customer', val])
            this.thr_search()
      }
    }
}
</script>