// 1 => LOADING
// 2 => DONE
// 3 => ERROR
import * as api from "./api_salesorder.js"
import { one_token } from "../../assets/js/global.js"

export default {
    namespaced: true,
    state: {
        search_status: 0,
        search_error_message: '',
        search: '',
        
        items: [],
        total_item: 0,
        selected_item: {},

        expeditions: [],
        total_expedition: 0,
        selected_expedition: {},

        services: [],
        total_service: 0,
        selected_service: {},
        loading_service: false,

        payments: [],
        total_payment: 0,
        selected_payment: {},
        selected_payment_id: 0,

        accounts: [],

        ds_customers: [],
        selected_ds_customer: null,
        search_ds_customer: '',

        total_weight: 0,
        courier_cost: 0,
        is_dropship: 'N',

        current_page: 1,
        tabs: [1,2],
        selected_tab: 1
    },
    mutations: {
        set_common(state, v) {
            let name = v[0]
            let val = v[1]
            if (typeof(val) == "string")
                eval(`state.${name} = "${val}"`)
            else
                eval(`state.${name} = ${val}`)
        },

        update_search_error_message(state, msg) {
            state.search_error_message = msg
        },

        update_search(state, search) {
            state.search = search
        },

        update_items(state, data) {
            state.items = data

            let t = 0
            for (let d of data)
                t += parseFloat(d.item_weight * d.item_qty)

            state.total_weight = t
        },

        set_selected_item(state, val) {
            state.selected_item = val
        },

        update_search_status(state, val) {
            state.search_status = val
        },

        update_total_item(state, val) {
            state.total_item = val
        },

        set_expeditions(state, data) {
            state.expeditions = data
        },

        set_selected_expedition(state, val) {
            state.selected_expedition = val
        },

        set_payments(state, data) {
            state.payments = data
        },

        set_selected_payment(state, val) {
            state.selected_payment = val
        },

        set_services(state, data) {
            state.services = data
        },

        set_accounts(state, data) {
            state.accounts = data
        },

        set_selected_service(state, val) {
            state.selected_service = val
            if (!val)
                state.courier_cost = 0
            else
                state.courier_cost = parseFloat(val.cost[0].value)
        },

        update_current_page(state, val) {
            state.current_page = val
        },

        set_ds_customers(state, data) {
            state.ds_customers = data
        },

        set_selected_ds_customer(state, val) {
            state.selected_ds_customer = val
        }
    },
    actions: {
        async save(context) {
            context.commit("update_search_status", 1)
            context.commit("set_dialog_progress", true, {root:true})
            try {
                let prm = {
                    order_id: 0,
                    customer_id: 1,
                    expedition_id: context.state.selected_expedition.M_ExpeditionID,
                    service: context.state.selected_service.service,
                    courier_cost: context.state.courier_cost,
                    payment_id: context.state.selected_payment_id,
                    json_data: context.state.items,
                    is_dropship: context.state.is_dropship,
                    ds_customer_id: context.state.is_dropship == "Y" ? context.state.selected_ds_customer.M_CustomerID : 0,
                    token: one_token()
                }

                let resp = await api.save(prm)
                context.commit("set_dialog_progress", false, {root:true})
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    console.log(resp)
                    window.location = '../sales-order-seller-list/'
                }
            } catch (e) {
                context.commit("set_dialog_progress", false, {root:true})
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_expedition(context) {
            context.commit("update_search_status", 1)
            try {
                let prm = {
                    token: one_token()
                }

                let resp = await api.search_expedition(prm)
                
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    let data = {
                        records: resp.data.records,
                        total: resp.data.total
                    }

                    context.commit("set_expeditions", data.records)
                    context.commit("set_common", ["set_total_expedition", data.total])
                }
            } catch (e) {
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_service(context) {
            context.commit("update_search_status", 1)
            context.commit('set_common', ['loading_service', true])
            try {
                let prm = {
                    token: one_token(),
                    to: 279,
                    courier: context.state.selected_expedition.M_ExpeditionROCode,
                    weight: context.state.total_weight
                }

                let resp = await api.search_service(prm)
                context.commit('set_common', ['loading_service', false])
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    let data = JSON.parse(resp.data)

                    context.commit("set_services", data.rajaongkir.results[0].costs)
                }
            } catch (e) {
                context.commit('set_common', ['loading_service', false])
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_payment(context) {
            context.commit("update_search_status", 1)
            try {
                let prm = {
                    token: one_token()
                }

                let resp = await api.search_payment(prm)
                
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    let data = {
                        records: resp.data.records,
                        total: resp.data.total
                    }

                    context.commit("set_payments", data.records)
                    context.commit("set_common", ["set_total_payment", data.total])
                }
            } catch (e) {
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_ds_customer(context) {
            context.commit("update_search_status", 1)
            try {
                let prm = {
                    token: one_token(),
                    search: context.state.search_ds_customer
                }

                let resp = await api.search_ds_customer(prm)
                
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    context.commit("set_ds_customers", resp.data.records)
                }
            } catch (e) {
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_account(context) {
            context.commit("update_search_status", 1)
            try {
                let prm = {
                    token: one_token()
                }

                let resp = await api.search_account(prm)
                
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    let data = {
                        records: resp.data.records,
                        total: resp.data.total
                    }

                    context.commit("set_accounts", data.records)
                }
            } catch (e) {
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        }
    }
}