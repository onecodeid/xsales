<template>
    <v-layout row wrap>
        <v-flex xs12>
            <v-card>
                <v-card-text>
                    <h3 class="font-weight-light">Sedang dalam perbaikan</h3>
                </v-card-text>
            </v-card>
        </v-flex>
    </v-layout>
</template>

<script>
module.exports = {
    data () {
        return {
            
        }
    }
}
</script>