<template>
    <v-card>
        <v-card-title primary-title class="pt-2 pb-0">
            <v-layout row wrap>
                <v-flex xs9>
                    <h3 class="display-1 font-weight-light zalfa-text-title">Masterdata Item</h3>
                </v-flex>
                <v-flex xs3 class="text-xs-right">
                    <!-- <v-btn color="success" class="ma-0 btn-icon" @click="add">
                        <v-icon>add</v-icon>
                    </v-btn> -->

                    <v-text-field
                        solo
                        hide-details
                        placeholder="Pencarian" v-model="query"
                        @change="search"
                    >
                        <template v-slot:append-outer>
                            <v-btn color="primary" class="ma-0 btn-icon" @click="search">
                                <v-icon>search</v-icon>
                            </v-btn>      

                            <v-btn color="success" class="ma-0 ml-2 btn-icon" @click="add">
                                <v-icon>add</v-icon>
                            </v-btn>  
                        </template>
                    </v-text-field>
                </v-flex>
            </v-layout>
        </v-card-title>
        <v-card-text class="pt-2">
            <v-data-table 
                :headers="headers"
                :items="items"
                :loading="false"
                hide-actions
                class="elevation-1">
                <template slot="items" slot-scope="props">
                    <td class="text-xs-left pa-0 pt-1 pl-1" @click="select(props.item)">
                        <img :src="props.item.img_url" height="60" /></td>
                    
                    <td class="text-xs-center pa-2" @click="select(props.item)">{{ props.item.M_ItemCode }}</td>
                    <td class="text-xs-left pa-2" @click="select(props.item)">{{ props.item.M_ItemName }}</td>
                    <td class="text-xs-right pa-2" @click="select(props.item)">{{ one_money(props.item.M_ItemWeight) }} gr</td>
                    <td class="text-xs-right pa-2" @click="select(props.item)">{{ one_money(props.item.M_ItemMinStock) }}</td>

                    <td v-show="parseFloat(props.item.I_StockQty) >= parseFloat(props.item.M_ItemMinStock)" class="text-xs-right pa-2" @click="select(props.item)">{{ one_money(props.item.I_StockQty) }}</td>
                    <td v-show="parseFloat(props.item.I_StockQty) < parseFloat(props.item.M_ItemMinStock)" class="text-xs-right pa-2" @click="select(props.item)"><v-icon style="float:left" class="ml-2 red--text">priority_high</v-icon>{{ one_money(props.item.I_StockQty) }}</td>

                    <td class="text-xs-center pa-2" @click="select(props.item)">{{ props.item.M_UnitName }}</td>
                    
                    
                    <td class="text-xs-center pa-0" @click="select(props.item)">
                        <v-btn color="primary" class="btn-icon ma-0" small @click="edit(props.item)"><v-icon>create</v-icon></v-btn>
                        <v-btn color="red" dark class="btn-icon ma-0" small @click="del(props.item)"><v-icon>delete</v-icon></v-btn>
                    </td>
                    <!-- <td class="text-xs-center pa-2" v-bind:class="{'amber lighten-4':isSelected(props.item)}" @click="selectMe(props.item)">{{ props.item.M_DoctorHP}}</td>
                    <td class="text-xs-left pa-2" v-bind:class="{'amber lighten-4':isSelected(props.item)}" @click="selectMe(props.item)">{{ props.item.status}}</td> -->
                </template>
            </v-data-table>
            <v-divider></v-divider>
            <v-pagination
                style="margin-top:10px;margin-bottom:10px"
                v-model="curr_page"
                :length="xtotal_page"
                @input="change_page"
            ></v-pagination>
        </v-card-text>
        
        <common-dialog-delete :data="item_id" @confirm_del="confirm_del" v-if="dialog_delete"></common-dialog-delete>
    </v-card>
</template>

<style scoped>
.v-text-field.v-text-field--solo .v-input__control {
    min-height: 36px;
}
.v-text-field.v-text-field--solo .v-input__append-outer {
    margin-top: 0px;
    margin-left: 0px;
}
</style>

<script>
module.exports = {
    components : {
        "common-dialog-delete" : httpVueLoader("../../common/components/common-dialog-delete.vue")
    },

    data () {
        return {
            headers: [
                {
                    text: "#",
                    align: "left",
                    sortable: false,
                    width: "5%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "KODE",
                    align: "center",
                    sortable: false,
                    width: "5%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "NAMA",
                    align: "left",
                    sortable: false,
                    width: "44%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "BERAT",
                    align: "right",
                    sortable: false,
                    width: "7%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "STOK MIN",
                    align: "right",
                    sortable: false,
                    width: "7%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "STOK GUDANG",
                    align: "right",
                    sortable: false,
                    width: "7%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "UNIT",
                    align: "center",
                    sortable: false,
                    width: "5%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "ACTION",
                    align: "center",
                    sortable: false,
                    width: "10%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                }
            ]
        }
    },

    computed : {
        items () {
            return this.$store.state.item.items
        },

        dialog_delete () {
            return this.$store.state.dialog_delete
        },

        item_id () {
            return this.$store.state.item.selected_item.M_ItemID
        },

        query : {
            get () { return this.$store.state.item.search },
            set (v) { this.$store.commit('item/update_search', v) }
        },

        curr_page : {
            get () { return this.$store.state.item.current_page },
            set (v) { this.$store.commit('item/update_current_page', v) }
        },

        xtotal_page () {
            return this.$store.state.item.total_item_page
        }
    },

    methods : {
        one_money (x) {
            return window.one_money(x)
        },

        add () {
            this.$store.dispatch('item_new/search_level_price', {})
            this.$store.commit('item_new/set_common', ['edit', false])
            this.$store.commit('item_new/set_common', ['item_name', ''])
            this.$store.commit('item_new/set_common', ['item_code', ''])
            this.$store.commit('item_new/set_common', ['item_weight', 0])
            this.$store.commit('item_new/set_common', ['item_img', ''])
            this.$store.commit('item_new/set_common', ['item_min', 0])
            this.$store.commit('item_new/set_common', ['item_hpp', 0])
            this.$store.commit('item_new/set_selected_unit', null)
            this.$store.commit('item_new/set_dialog_new', true)
        },

        edit (x) {
            this.select(x)
            let sc = x
            this.$store.commit('item_new/set_common', ['edit', true])
            this.$store.commit('item_new/set_common', ['item_name', sc.M_ItemName])
            this.$store.commit('item_new/set_common', ['item_code', sc.M_ItemCode])
            this.$store.commit('item_new/set_common', ['item_weight', sc.M_ItemWeight])
            this.$store.commit('item_new/set_common', ['item_img', sc.img_uri])
            this.$store.commit('item_new/set_common', ['item_min', sc.M_ItemMinStock])
            this.$store.commit('item_new/set_common', ['item_hpp', sc.M_ItemHPP])

            // UNIT
            let u = this.$store.state.item_new.units
            this.$store.commit('item_new/set_selected_unit', null)
            for (let x of u)
                if (x.M_UnitID == sc.M_ItemM_UnitID)
                    this.$store.commit('item_new/set_selected_unit', x)

            this.$store.commit('item_new/set_levels', x.prices)
            this.$store.commit('item_new/set_fees', x.fees)
            // this.$store.commit('item_new/set_common', ['item_', sc.full_address])
            // this.$store.commit('item_new/set_selected_city', {kelurahan_id:sc.kelurahan_id,full_address:sc.full_address})
            this.$store.commit('item_new/set_dialog_new', true)
        },

        del (x) {
            this.select(x)
            this.$store.commit('set_dialog_delete', true)
        },

        confirm_del (x) {
            this.$store.dispatch('item/del', {id:x.data})
        },

        select (x) {
            this.$store.commit('item/set_selected_item', x)
        },

        search () {
            return this.$store.dispatch('item/search', {})
        },

        change_page(x) {
            this.curr_page = x
            this.$store.dispatch('item/search', {})
        }
    }
}
</script>