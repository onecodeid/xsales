<template>
    <v-dialog
        v-model="dialog"
        scrollable
        :overlay="false"
        max-width="1000px"
        transition="dialog-transition"
    >
        <v-card>
            <v-card-title primary-title class="cyan white--text pt-3">
                <h3>ITEM BARU</h3>
            </v-card-title>
            <v-card-text>
                <v-layout row wrap>
                    <v-flex xs6 pr-5>
                        <v-layout row wrap>
                            <v-flex xs12 :class="`mt-`+v_space">
                                <v-text-field
                                    label="Nama Barang"
                                    v-model="item_name"
                                ></v-text-field>
                            </v-flex>

                            <!-- <v-flex xs6 pr-3>
                                
                            </v-flex> -->

                            

                            

                            <v-flex xs6 :class="`mt-`+v_space+` pr-5`">
                                <v-text-field
                                    label="Kode Barang (SKU)"
                                    v-model="item_code"
                                ></v-text-field>

                                <v-select
                                    :items="units"
                                    v-model="selected_unit"
                                    return-object
                                    label="Satuan"
                                    item-key="M_UnitID"
                                    item-text="M_UnitName"
                                ></v-select>

                                <v-text-field
                                    label="Berat / Satuan"
                                    v-model="item_weight"
                                    suffix="gram"
                                ></v-text-field>

                                <v-text-field
                                    label="Min Stock"
                                    v-model="item_min"
                                    :suffix="selected_unit ? selected_unit.M_UnitName : '#'"
                                ></v-text-field>

                                <v-text-field
                                    label="HPP / Harga Produksi"
                                    v-model="item_hpp"
                                    class="text-xs-right"
                                    suffix="Rp"
                                    reverse
                                >
                                    <template slot="label" style="left:0px;right:auto">
                                        <div style="left:0px;right:auto">HPP</div>
                                    </template>
                                </v-text-field>
                                
                            </v-flex>

                            
                            <v-flex xs6 align-center
          justify-center>
                                <v-img :src="item_img" position="center center" class="ma-3">
                                </v-img>
                                <v-text-field label="Select Image" @click='pickFile' v-model='imageName' prepend-icon='attach_file'></v-text-field>
                                
                                <input
                                    type="file"
                                    style="display: none"
                                    ref="image"
                                    accept="image/*"
                                    @change="onFilePicked"
                                >
                            </v-flex>
                            
                            <v-flex xs6  :class="[`mt-`+v_space, 'pl-4']">
                                
                            </v-flex>
                        </v-layout>
                    </v-flex>

                    <v-flex xs6>
                        <v-layout row wrap>
                            <v-data-table 
                                :headers="headers"
                                :items="levels"
                                :loading="false"
                                hide-actions
                                class="elevation-1">
                                <template slot="items" slot-scope="props">
                                    <td class="text-xs-left pa-2">{{ props.item.M_CustomerLevelName }}</td>
                                    <td class="text-xs-left pa-2">
                                        <v-text-field
                                            solo
                                            :value="props.item.M_PriceAmount"
                                            hide-details
                                            reverse
                                            class="input-dense"
                                            @input="change_price('Amount', props.index, $event)"
                                        ></v-text-field>
                                    </td>

                                    <td class="text-xs-left pa-2">
                                        <v-text-field
                                            solo
                                            :value="props.item.M_PriceDiscRp"
                                            hide-details
                                            reverse
                                            class="input-dense"
                                            @input="change_price('DiscRp', props.index, $event)"
                                        ></v-text-field>
                                    </td>

                                    <td class="text-xs-left pa-2">
                                        <v-text-field
                                            solo
                                            :value="props.item.M_PriceTotal"
                                            hide-details
                                            reverse
                                            class="input-dense"
                                            disabled
                                        ></v-text-field>
                                    </td>

                                    <td class="text-xs-left pa-2 zalfa-bg-cyan lighten-5">
                                        <v-text-field
                                            solo
                                            :value="fees[props.index] ? fees[props.index].M_FeeAmount : 0"
                                            hide-details
                                            reverse
                                            class="input-dense"
                                            @input="change_price('fee', props.index, $event)"
                                        ></v-text-field>
                                    </td>
                                    <!-- <td class="text-xs-center pa-2" v-bind:class="{'amber lighten-4':isSelected(props.item)}" @click="selectMe(props.item)">{{ props.item.M_DoctorHP}}</td>
                                    <td class="text-xs-left pa-2" v-bind:class="{'amber lighten-4':isSelected(props.item)}" @click="selectMe(props.item)">{{ props.item.status}}</td> -->
                                </template>
                            </v-data-table>
                            <v-divider></v-divider>

                            
                        </v-layout>
                    </v-flex>
                </v-layout>
            </v-card-text>

            <v-card-actions>
                <v-btn color="primary" flat @click="dialog=!dialog">Batal</v-btn>
                <v-spacer></v-spacer>
                <v-btn color="primary" @click="save">Simpan</v-btn>                
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<style>
.input-dense .v-input__control {
    min-height: 36px !important;
}
</style>
<script>
module.exports = {
    data () {
        return {
            headers: [
                {
                    text: "LEVEL",
                    align: "center",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "HARGA",
                    align: "center",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "DISKON",
                    align: "center",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "TOTAL",
                    align: "center",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "KOMISI",
                    align: "center",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-cyan lighten-3 white--text"
                }
            ],

            imageName: '',
            imageUrl: '',
            imageFile: ''
        }
    },

    computed : {
        dialog : {
            get () { return this.$store.state.item_new.dialog_new },
            set (v) { this.$store.commit('item_new/set_common', ['dialog_new', v]) }
        },

        item_name : {
            get () { return this.$store.state.item_new.item_name },
            set (v) { this.$store.commit('item_new/set_common', ['item_name', v]) }
        },

        item_code : {
            get () { return this.$store.state.item_new.item_code },
            set (v) { this.$store.commit('item_new/set_common', ['item_code', v]) }
        },

        item_weight : {
            get () { return this.$store.state.item_new.item_weight },
            set (v) { this.$store.commit('item_new/set_common', ['item_weight', v]) }
        },

        item_img : {
            get () {
                if (this.$store.state.item_new.item_img)
                    return this.$store.state.item_new.item_img
                return ''
            },
            set (v) { this.$store.commit('item_new/set_common', ['item_img', v]) }
        },

        item_min : {
            get () { return this.$store.state.item_new.item_min },
            set (v) { this.$store.commit('item_new/set_common', ['item_min', v]) }
        },

        item_hpp : {
            get () { return this.$store.state.item_new.item_hpp },
            set (v) { this.$store.commit('item_new/set_common', ['item_hpp', v]) }
        },

        units () {
            return this.$store.state.item_new.units
        },

        selected_unit : {
            get () { return this.$store.state.item_new.selected_unit },
            set (v) { this.$store.commit('item_new/set_selected_unit', v) }
        },

        v_space () {
            return 0
        },

        levels () {
            return this.$store.state.item_new.levels
        },

        fees () {
            return this.$store.state.item_new.fees
        }
    },

    methods : {
        save () {
            this.$store.dispatch('item_new/save')
        },

        change_price(type, i, v) {
            if (type == "fee") {
                let x = this.fees
                x[i][`M_FeeAmount`] = v
                this.$store.commit('item_new/set_fees', x)
            } else {
                let x = this.levels
                x[i][`M_Price${type}`] = v
                x[i][`M_PriceTotal`] = parseFloat(x[i]['M_PriceAmount']) - parseFloat(x[i]['M_PriceDiscRp'])

                this.$store.commit('item_new/set_levels', x)
            }
        },

        pickFile () {
            this.$refs.image.click ()
        },

        onFilePicked (e) {
			const files = e.target.files
			if(files[0] !== undefined) {
                this.imageName = files[0].name
                
				if(this.imageName.lastIndexOf('.') <= 0) {
					return
				}
				const fr = new FileReader ()
                fr.readAsDataURL(files[0])
				fr.addEventListener('load', () => {
                    this.imageUrl = fr.result
                    this.imageFile = files[0] // this is an image file that can be sent to server...
                    this.getBase64(files[0])
				})
			} else {
				this.imageName = ''
				this.imageFile = ''
				this.imageUrl = ''
			}
        },
        
        getBase64(file) {
            let vue = this
            let photo_uri = ''
            var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function () {
            //   console.log(reader.result);
                photo_uri = reader.result
                vue.item_img = photo_uri
                reader.onerror = function (error) {
                    console.log('Error: ', error);
                };
            }

            
        }
    },

    mounted () {
        this.$store.dispatch('item_new/search_unit', [])
        this.$store.dispatch('item_new/search_level_price', [])
    },

    watch : {
        
    }
}
</script>