<template>
  <v-toolbar dark class="zalfa-bg-pink-01">
    <v-toolbar-side-icon @click="drawer=!drawer"></v-toolbar-side-icon>

    <v-toolbar-title class="white--text">Zalfa Miracle</v-toolbar-title>

    <v-spacer></v-spacer>

    <!-- <v-btn icon>
      <v-icon>search</v-icon>
    </v-btn>

    <v-btn icon>
      <v-icon>apps</v-icon>
    </v-btn>

    <v-btn icon>
      <v-icon>refresh</v-icon>
    </v-btn> -->

    <!-- <v-btn icon>
      <v-icon>more_vert</v-icon>
    </v-btn> -->

    <h3>{{ user.user_name }}</h3>
    <v-menu
      :close-on-content-click="true"
      :nudge-width="200"
      offset-overflow
      left
      bottom
    >
      <template v-slot:activator="{ on }">
        <v-btn
          class="ml-4" icon
          v-on="on"
        >
          <v-icon>more_vert</v-icon>
        </v-btn>
      </template>

      <v-card>
        <!-- <v-list>
          <v-list-tile avatar>

            <v-list-tile-content>
              <v-list-tile-title>{{ user.user_name }}</v-list-tile-title>
              <v-list-tile-sub-title>{{ user.customer_name }}</v-list-tile-sub-title>
            </v-list-tile-content>
            
          </v-list-tile>
        </v-list>

        <v-divider></v-divider> -->

        <v-list class="pa-0 profile-menu">
          <v-list-tile @click="change_password" >
             <v-list-tile-action>
                 <v-icon>security</v-icon>
             </v-list-tile-action>
             <v-list-tile-title>Change Password</v-list-tile-title>
          </v-list-tile>

        </v-list>
        <v-list class="pa-0 profile-menu">
          <v-list-tile @click="logout" >
             <v-list-tile-action>
                 <v-icon>no_meeting_room</v-icon>
             </v-list-tile-action>
             <v-list-tile-title>Log Out</v-list-tile-title>
          </v-list-tile>

        </v-list>

        
      </v-card>
    </v-menu>

  </v-toolbar>
</template>

<style>
    .profile-menu .v-list__tile {
        font-size: 13px;
        height: 40px;
    }

    .profile-menu .v-list__tile__action {
        min-width: 30px;
    }

    .profile-menu .v-list__tile__action .v-icon {
        font-size: 18px;
    }
</style>
<script>
module.exports = {
    data () {
        return {
            drawer_notification: false,
            user: this.$store.state.system.user
        }
    },

    computed : {
        drawer : {
            get () { return this.$store.state.system.drawer },
            set (v) { this.$store.commit('system/set_drawer', v) }
        }
    },

    methods : {
        change_password () {
            window.location.replace('../system-profile/?tab=2')
        },

        logout () {
            this.$store.dispatch('system/do_logout')
        }
    }
}
</script>