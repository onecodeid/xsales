<template>
    <v-card>
        <v-card-title primary-title class="pt-2 pb-0">
            <v-layout row wrap>
                <v-flex xs9>
                    <h3 class="display-1 font-weight-light zalfa-text-title">Masterdata Paket</h3>
                </v-flex>
                <v-flex xs3 class="text-xs-right">
                    <v-btn color="success" class="ma-0 btn-icon" @click="add">
                        <v-icon>add</v-icon>
                    </v-btn>
                </v-flex>
            </v-layout>
        </v-card-title>
        <v-card-text class="pt-2">
            <v-data-table 
                :headers="headers"
                :items="packets"
                :loading="false"
                hide-actions
                class="elevation-1">
                <template slot="items" slot-scope="props">
                    <td class="text-xs-left pa-0 pt-1 pl-1" @click="select(props.item)" v-bind:class="[is_selected(props.item)?class_selected:'']">
                        {{ props.item.M_PacketCode }}</td>
                    <td class="text-xs-left pa-2" @click="select(props.item)" v-bind:class="[is_selected(props.item)?class_selected:'']">{{ props.item.M_PacketName }}</td>
                    
                    
                    <td class="text-xs-left pa-0" @click="select(props.item)" v-bind:class="[is_selected(props.item)?class_selected:'']">
                        <v-btn color="primary" class="btn-icon ma-0" small @click="edit(props.item)"><v-icon>create</v-icon></v-btn>
                        <v-btn color="red" dark class="btn-icon ma-0" small @click="del(props.item)"><v-icon>delete</v-icon></v-btn>
                    </td>
                    <!-- <td class="text-xs-center pa-2" v-bind:class="{'amber lighten-4':isSelected(props.item)}" @click="selectMe(props.item)">{{ props.item.M_DoctorHP}}</td>
                    <td class="text-xs-left pa-2" v-bind:class="{'amber lighten-4':isSelected(props.item)}" @click="selectMe(props.item)">{{ props.item.status}}</td> -->
                </template>
            </v-data-table>
            <v-divider></v-divider>
            <v-pagination
                style="margin-top:10px;margin-bottom:10px"
                v-model="curr_page"
                :length="xtotal_page"
            ></v-pagination>
        </v-card-text>
        
        <common-dialog-delete :data="packet_id" @confirm_del="confirm_del" v-if="dialog_delete"></common-dialog-delete>
    </v-card>
</template>

<script>
module.exports = {
    components : {
        "common-dialog-delete" : httpVueLoader("../../common/components/common-dialog-delete.vue")
    },

    data () {
        return {
            curr_page: 1,
            xtotal_page: 1,
            headers: [
                {
                    text: "KODE",
                    align: "left",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "NAMA",
                    align: "left",
                    sortable: false,
                    width: "60%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "ACTION",
                    align: "center",
                    sortable: false,
                    width: "20%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                }
            ],
            class_selected: 'cyan lighten-4'
        }
    },

    computed : {
        packets () {
            return this.$store.state.packet.packets
        },

        dialog_delete () {
            return this.$store.state.dialog_delete
        },

        packet_id () {
            if (this.$store.state.packet.selected_packet)
                return this.$store.state.packet.selected_packet.M_PacketID
            return 0
        },

        selected_packet () {
            return this.$store.state.packet.selected_packet
        }
    },

    methods : {
        add () {
            this.$store.commit('packet_new/set_common', ['edit', false])
            this.$store.commit('packet_new/set_dialog_new', true)
        },

        edit (x) {
            this.select(x)
            let sc = x
            this.$store.commit('packet_new/set_common', ['edit', true])
            this.$store.commit('packet_new/set_common', ['packet_name', sc.M_PacketName])
            this.$store.commit('packet_new/set_common', ['packet_code', sc.M_PacketCode])

            this.$store.commit('packet_new/set_dialog_new', true)
        },

        del (x) {
            this.select(x)
            this.$store.commit('set_dialog_delete', true)
        },

        confirm_del (x) {
            this.$store.dispatch('packet/del', {id:x.data})
        },

        select (x) {
            this.$store.commit('packet/set_selected_packet', x)
            this.$store.dispatch('packetdetail/search', {})
        },

        is_selected (x) {
            if (this.selected_packet)
                if (this.selected_packet.M_PacketID == x.M_PacketID)
                    return true
            return false
        }
    }
}
</script>