<template>
    <v-dialog
        v-model="dialog"
        scrollable
        :overlay="false"
        max-width="300px"
        transition="dialog-transition"
    >
        <v-card>
            <v-card-title primary-title>
                <h3>PAKET BARU</h3>
            </v-card-title>
            <v-card-text>
                <v-layout row wrap>
                    <v-flex xs12>
                        <v-layout row wrap>
                            <v-flex xs12 mt-3>
                                <v-text-field
                                    label="Kode Paket"
                                    hide-details
                                    v-model="packet_code"
                                ></v-text-field>
                            </v-flex>

                            <v-flex xs12 :class="`mt-`+v_space">
                                <v-text-field
                                    label="Nama Paket"
                                    hide-details
                                    v-model="packet_name"
                                ></v-text-field>
                            </v-flex>

                        </v-layout>
                    </v-flex>
                </v-layout>
            </v-card-text>

            <v-card-actions>
                <v-btn color="primary" flat @click="dialog=!dialog">Batal</v-btn>
                <v-spacer></v-spacer>
                <v-btn color="primary" @click="save">Simpan</v-btn>                
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script>
module.exports = {
    data () {
        return {
        }
    },

    computed : {
        dialog : {
            get () { return this.$store.state.packet_new.dialog_new },
            set (v) { this.$store.commit('packet_new/set_common', ['dialog_new', v]) }
        },

        packet_name : {
            get () { return this.$store.state.packet_new.packet_name },
            set (v) { this.$store.commit('packet_new/set_common', ['packet_name', v]) }
        },

        packet_code : {
            get () { return this.$store.state.packet_new.packet_code },
            set (v) { this.$store.commit('packet_new/set_common', ['packet_code', v]) }
        },

        v_space () {
            return 3
        }
    },

    methods : {
        save () {
            this.$store.dispatch('packet_new/save')
        }
    },

    mounted () {
        
    },

    watch : {
        
    }
}
</script>