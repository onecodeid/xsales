<template>
<v-dialog
    v-model="dialog"
    scrollable
    persistent 
    max-width="1000px"
    transition="dialog-transition"
>
    <v-layout row wrap>
        <v-flex xs6>
            <v-card>
                <v-card-title primary-title class="pb-0 pt-3">
                    <v-layout row wrap>
                        <v-flex xs6>
                            <h3 class="headline mb-0">Detail Order</h3>        
                        </v-flex>
                        <v-flex xs6 class="text-xs-right">
                            <h3>Invoice No #{{ selected_order.L_SoNumber }}</h3>
                            <p class="mb-0">{{ selected_order.L_SoDate }}</p>
                        </v-flex>
                    </v-layout>
                </v-card-title>
                <v-card-text>
                    <v-layout row wrap>
                        <v-flex xs12>
                            
                            <v-layout row wrap mb-4>
                                <v-flex xs12>
                                    <h3 class="">{{ selected_order.M_CustomerName }}</h3>
                                    <p class="mb-0">{{ selected_order.M_CustomerAddress }}</p>
                                    <p class="mb-0">{{ selected_order.city_name }}</p>
                                </v-flex>    
                            </v-layout>

                            <v-card flat>
                                <v-card-title primary-title class="orange white--text pt-2 pb-2">
                                    <v-layout row wrap>
                                        <v-flex xs6>
                                            <h4>Metode Pembayaran</h4>
                                        </v-flex>
                                        <v-flex xs6 class="text-xs-right">
                                            <h4>Jumlah</h4>
                                        </v-flex>
                                    </v-layout>
                                    
                                </v-card-title>

                                <v-card-text>
                                    <v-layout row wrap>
                                        <v-flex xs9>
                                            <div><b>{{ selected_order.M_PaymentTypeName }}</b></div>
                                            <div>{{ selected_order.account_bank_name }} No. {{ selected_order.M_BankAccountNumber }}</div>
                                            <div>a/n {{ selected_order.M_BankAccountName }}</div>

                                            <div class="mt-3"><b>BANK PENGIRIM</b></div>
                                            <div>{{ selected_order.M_BankName }} a/n {{ selected_order.F_PaymentSenderName }}</div>
                                            
                                        </v-flex>
                                        <v-flex xs3 class="text-xs-right">
                                            <div>Rp <b>{{ one_money(selected_order.F_PaymentAmount) }}</b></div>
                                            <div>&nbsp;</div>
                                            <div class="mt-3">{{ selected_order.F_PaymentDate }}</div>
                                        </v-flex>
                                    </v-layout>
                                </v-card-text>
                            </v-card>

                            <v-card flat>
                                <v-card-title primary-title class="black white--text pt-2 pb-2">
                                    <v-layout row wrap>
                                        <v-flex xs6>
                                            <h4>Item</h4>
                                        </v-flex>
                                        <v-flex xs6 class="text-xs-right">
                                            <h4>Total Tagihan</h4>
                                        </v-flex>
                                    </v-layout>
                                    
                                </v-card-title>

                                <v-card-text>
                                    <v-layout row wrap>
                                        <v-flex xs9>
                                            <div>
                                                <template v-for="(item, i) of selected_order.items">
                                                    <div :class="(i%2==0? 'blue--text':'') + ' mr-2'" v-bind:key="i">{{ item.item_name }} ({{ item.item_qty }})</div>
                                                </template>
                                            </div>
                                            
                                        </v-flex>
                                        <v-flex xs3 class="text-xs-right">
                                            <div>Rp <b>{{ one_money(selected_order.L_SoTotal) }}</b></div>
                                        </v-flex>
                                    </v-layout>
                                </v-card-text>
                            </v-card>

                        </v-flex>
                        
                    </v-layout>
                    

                </v-card-text>
                <v-card-actions>
                    <v-btn flat color="primary" @click="dialog=!dialog">Tutup</v-btn>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" @click="confirm">Konfirmasi</v-btn>
                    
                </v-card-actions>
            </v-card>
        </v-flex>

        <v-flex xs6>
            <v-card class="fill-height">
                <v-card-text style="height:100%">
                    <object :data="report_url" type="application/pdf" width="100%" height="100%"></object>
                </v-card-text>
            </v-card>
        </v-flex>
    </v-layout>
    
</v-dialog>
    
</template>

<style>
.zalfa-line-trough {
    text-decoration: line-through;
}

.zalfa-input-super-dense .v-input__control {
    min-height: 36px !important;
}
</style>

<script>
module.exports = {
    data () {
        return {
            w : [],
            headers: [
                {
                    text: "#",
                    align: "left",
                    sortable: false,
                    width: "10%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "NAMA BARANG",
                    align: "center",
                    sortable: false,
                    width: "35%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "QTY",
                    align: "right",
                    sortable: false,
                    width: "10%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "APPR QTY",
                    align: "right",
                    sortable: false,
                    width: "10%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "STOK",
                    align: "right",
                    sortable: false,
                    width: "10%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "HARGA",
                    align: "right",
                    sortable: false,
                    width: "15%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "DISKON",
                    align: "right",
                    sortable: false,
                    width: "15%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "HARGA TOTAL",
                    align: "right",
                    sortable: false,
                    width: "15%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                }
            ],

            report_url : this.$store.state.payment.URL+"report/one_iv_001?soid="+4
        }
    },

    computed : {
        dialog : {
            get () { return this.$store.state.payment.dialog_item },
            set (v) { this.$store.commit('payment/set_common', ['dialog_item', v]) }
        },

        selected_order () {
            return this.$store.state.payment.selected_order
        }
    },

    methods : {
       one_money (x) {
           return window.one_money(x)
       },

        confirm () {
            this.$store.dispatch('payment/confirm')
        }
    },

    mounted () {
        
    },

    watch : {
        
    }
}
</script>