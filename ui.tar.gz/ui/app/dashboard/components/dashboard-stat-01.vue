<template>
    <v-layout row wrap>
        <v-flex xs3 pr-2 mb-2>
            <v-card>
                <v-card-text>
                    <v-layout row wrap>
                        <v-flex xs4>
                            <v-card color="blue zalfa-icon-box">
                                <v-card-text>
                                    <v-icon size="50" color="white" light>swap_horiz</v-icon>        
                                </v-card-text>
                            </v-card>
                            
                        </v-flex>
                        <v-flex xs8 class="text-xs-right">
                            <div class="subheading font-weight-thin">Transaksi Hari Ini</div>
                            <h4 class="headline">34</h4>
                        </v-flex>
                        <v-flex xs12>
                            <v-divider class="mt-2 mb-2"></v-divider>
                            <div class="body-1 font-weight-light"><v-icon size="20">history</v-icon> Last updated : 2020-04-01 09:00</div>
                        </v-flex>
                    </v-layout>
                    
                    
                </v-card-text>
            </v-card>
        </v-flex>

        <v-flex xs3 pr-2 mb-2>
            <v-card>
                <v-card-text>
                    <v-layout row wrap>
                        <v-flex xs4>
                            <v-card color="green zalfa-icon-box">
                                <v-card-text>
                                    <v-icon size="50" color="white" light>attach_money</v-icon>        
                                </v-card-text>
                            </v-card>
                            
                        </v-flex>
                        <v-flex xs8 class="text-xs-right">
                            <div class="subheading font-weight-thin">Komisi Bulan Ini</div>
                            <h4 class="headline">Rp 345,000</h4>
                        </v-flex>
                        <v-flex xs12>
                            <v-divider class="mt-2 mb-2"></v-divider>
                            <div class="body-1 font-weight-light"><v-icon size="20">history</v-icon> Last updated : 2020-04-01 09:00</div>
                        </v-flex>
                    </v-layout>
                    
                    
                </v-card-text>
            </v-card>
        </v-flex>

        <v-flex xs3 pr-2 mb-2>
            <v-card>
                <v-card-text>
                    <v-layout row wrap>
                        <v-flex xs4>
                            <v-card color="orange zalfa-icon-box">
                                <v-card-text>
                                    <v-icon size="50" color="white" light>account_balance</v-icon>        
                                </v-card-text>
                            </v-card>
                            
                        </v-flex>
                        <v-flex xs8 class="text-xs-right">
                            <div class="subheading font-weight-thin">Saldo iPaymu</div>
                            <h4 class="headline">Rp {{ one_money(ipaymu_balance) }}</h4>
                        </v-flex>
                        <v-flex xs12>
                            <v-divider class="mt-2 mb-2"></v-divider>
                            <div class="body-1 font-weight-light"><v-icon size="20">history</v-icon> Last updated : 2020-04-01 09:00</div>
                        </v-flex>
                    </v-layout>
                    
                    
                </v-card-text>
            </v-card>
        </v-flex>

        <v-flex xs3 pr-2 mb-2>
            <v-card>
                <v-card-text>
                    <v-layout row wrap>
                        <v-flex xs4>
                            <v-card color="purple zalfa-icon-box">
                                <v-card-text>
                                    <v-icon size="50" color="white" light>local_shipping</v-icon>        
                                </v-card-text>
                            </v-card>
                            
                        </v-flex>
                        <v-flex xs8 class="text-xs-right">
                            <div class="subheading font-weight-thin">Order Belum Terkirim</div>
                            <h4 class="headline">14</h4>
                        </v-flex>
                        <v-flex xs12>
                            <v-divider class="mt-2 mb-2"></v-divider>
                            <div class="body-1 font-weight-light"><v-icon size="20">history</v-icon> Last updated : 2020-04-01 09:00</div>
                        </v-flex>
                    </v-layout>
                    
                    
                </v-card-text>
            </v-card>
        </v-flex>

        <v-flex xs3 pr-2 mb-2>
            <v-card>
                <v-card-text>
                    <v-layout row wrap>
                        
                        <v-flex xs12>
                            <object data="../objects/dashboard-chart-customer/"></object>
                        </v-flex>
                    </v-layout>
                    
                    
                </v-card-text>
            </v-card>
        </v-flex>
    </v-layout>
</template>

<style scoped>
    .zalfa-icon-box {
        margin-top: -30px
    }
</style>

<script>
module.exports = {
    computed : {
        ipaymu_balance () {
            return this.$store.state.dashboard.ipaymu_balance
        }
    },

    methods : {
        one_money (x) {
            return window.one_money(x)
        }
    }
}
</script>