<template>
    <v-dialog
        v-model="dialog"
        scrollable
        max-width="300px"
        transition="dialog-transition"
    >
        <v-card>
            <v-card-text>
                <v-layout row wrap>
                    <v-flex xs12>
                        <v-select
                            :items="expeditions"
                            v-model="selected_expedition"
                            item-text="M_ExpeditionName"
                            item-value="M_ExpeditionID"
                            label="Ekspedisi"
                            placeholder="Pilih salah satu"
                            hide-details
                            return-object
                        ></v-select>
                    </v-flex>

                    <v-flex xs12>
                        <v-select
                            :items="services"
                            v-model="selected_service"
                            item-text="service"
                            item-value="service"
                            label="Service"
                            placeholder="Pilih salah satu"
                            hide-details
                            return-object
                            :loading="loading_service"
                        ></v-select>
                    </v-flex>
                </v-layout>
            </v-card-text>
        </v-card>
    </v-dialog>
</template>

<script>
module.exports = {
    computed : {
        dialog : {
            get () { return this.$store.state.quickorder.dialog_expedition },
            set (v) { this.$store.commit('quickorder/set_common', ['dialog_expedition', v]) }
        },

        expeditions () {
            return this.$store.state.quickorder.expeditions
        },

        selected_expedition : {
            get () { return this.$store.state.quickorder.selected_expedition },
            set (v) { 
                this.$store.commit('quickorder/set_selected_expedition', v)
                this.$store.dispatch('quickorder/search_service', {})
            }
        },

        services () {
            return this.$store.state.quickorder.services
        },

        selected_service : {
            get () { return this.$store.state.quickorder.selected_service },
            set (v) { 
                this.$store.commit('quickorder/set_selected_service', v) 
                this.$store.commit('quickorder/set_common', ['courier_cost', v.cost[0].value])
            }
        },

        loading_service () {
            return this.$store.state.quickorder.loading_service
        }
    },

    mounted () {
        this.$store.dispatch('quickorder/search_expedition')
    }
}
</script>