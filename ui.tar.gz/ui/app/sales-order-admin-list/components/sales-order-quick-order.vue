<template>
    <v-dialog
        v-model="dialog"
        :height="height"
        scrollable
        persistent
        max-width="100%"
        transition="dialog-transition"
        content-class="zalfa-dialog-item"
    >
        <v-card>
            <v-card-title primary-title class="primary white--text pt-2 pb-2">
                <h3 class="headline">Pemesanan Cepat</h3>
            </v-card-title>
            <v-card-text>
                <v-layout row wrap>
                    <v-flex xs8>
                        <v-layout row wrap>
                            <v-flex xs6 v-for="(item,i) in items" :key="i" pl-1 pr-1 mb-1>
                                <v-card>
                                    <v-card-text class="pa-1" v-bind:class="is_selected_class(item)" @click="add(item)">
                                        <v-layout row wrap>
                                            <v-flex xs2>
                                                <v-img :src="item.img_url"></v-img>
                                            </v-flex>
                                            <v-flex xs10 pl-2>
                                                <div class="caption vertical-center">
                                                    {{item.M_ItemName}}<br />
                                                    Harga Rp {{one_money(item.M_PriceTotal)}}
                                                </div>
                                            </v-flex>
                                        </v-layout>
                                        
                                        
                                    </v-card-text>
                                </v-card>
                                
                            </v-flex>
                        </v-layout>
                    </v-flex>
                    <v-flex xs4 pl-2>
                        <div style="position:sticky;top:0">
                            <v-text-field
                                label="Nama Customer"
                                placeholder="Tulis nama yang lengkap"
                                v-model="cust_name"
                            ></v-text-field>

                            <v-autocomplete
                                v-model="selected_city"
                                :items="cities"
                                :search-input.sync="search_city"
                                auto-select-first
                                no-filter
                                return-object
                                :clearable="true"
                                item-text="full_address_reverse"
                                :loading="loading_city"
                                no-data-text="Pilih Kota / Kecamatan"
                                label="Kota / Kecamatan / Kelurahan"
                                placeholder="Ketikkan minimal 3 huruf"
                                >
                                <template
                                    slot="item"
                                    slot-scope="{ item }"
                                    >
                                    <v-list-tile-content>
                                        <v-list-tile-title v-text="item.full_address_reverse"></v-list-tile-title>
                                    </v-list-tile-content>
                                </template>

                            </v-autocomplete>

                            <v-textarea
                                label="Alamat Lengkap"
                                placeholder="Kota, Kecamatan, Kelurahan RT RW"
                                rows="2"
                                v-model="cust_address">
                                
                            </v-textarea>

                            <v-layout row wrap>
                                <v-flex xs4>
                                    <v-text-field
                                        label="Kode Pos"
                                        placeholder=" "
                                        v-model="cust_postcode"
                                    ></v-text-field>
                                </v-flex>
                                <v-flex xs8 pl-4>
                                    <v-text-field
                                        label="No Whatsapp"
                                        placeholder="Contoh : 0898XXX"
                                        v-model="cust_phone"
                                    ></v-text-field>
                                </v-flex>
                            </v-layout>

                            <v-layout row wrap>
                                <v-flex xs12>
                                    <v-data-table 
                                        :headers="headers"
                                        :items="details"
                                        :loading="false"
                                        hide-actions
                                        class="elevation-1 qo-detail-table">
                                        <template slot="items" slot-scope="props">
                                            <td class="text-xs-center pa-0" @click="select(props.item)">
                                                <v-btn color="red" class="btn-icon ma-0" small @click="del(props.index)" dark><v-icon>delete</v-icon></v-btn>
                                            </td>
                                            <td class="text-xs-left pa-2" @click="select(props.item)">{{ props.item.item_name }}</td>
                                            <td class="text-xs-left pa-2" @click="select(props.item)">{{ props.item.item_qty }}</td>
                                            <td class="text-xs-center pa-2" @click="select(props.item)">{{ one_money(props.item.item_subtotal) }}</td>
                                            
                                            
                                        </template>
                                    </v-data-table>
                                </v-flex>
                                <v-flex xs8 class="text-xs-right" mt-2>
                                    Total
                                </v-flex>
                                <v-flex xs4 class="text-xs-right" pr-3 mt-2>
                                    {{one_money(total)}}
                                </v-flex>
                                
                                <v-flex xs8 class="text-xs-right" mt-1>
                                    Ongkir
                                </v-flex>
                                <v-flex xs4 class="text-xs-right" pr-3 mt-1>
                                    {{one_money(exp_cost)}}
                                </v-flex>

                                <v-flex xs8 class="text-xs-right" mt-1>
                                    COD
                                </v-flex>
                                <v-flex xs4 class="text-xs-right" pr-3 mt-1>
                                    {{one_money(cod_cost)}}
                                </v-flex>

                                <v-flex xs8 class="text-xs-right subheading" mt-1>
                                    <b>Grand Total</b>
                                </v-flex>
                                <v-flex xs4 class="text-xs-right subheading" pr-3 mt-1>
                                    <b>{{one_money(grand_total)}}</b>
                                </v-flex>
                            </v-layout>
                        </div>
                    </v-flex>
                </v-layout>
            </v-card-text>
            <v-card-actions class="primary lighten-3">
                <div class="white--text font-weight-bold body-2">Ekspedisi : {{selected_expedition?selected_expedition.M_ExpeditionName:'-'}}, {{selected_service?selected_service.service:'-'}} 
                    <a href="#" class="ml-2" @click="edit_expedition">[ Ubah ]</a></div>
                <v-spacer></v-spacer>
                <v-btn color="red" dark @click="dialog=!dialog">Tutup</v-btn>
                <v-btn color="primary" @click="save" :disabled="!btn_save_enable">Simpan</v-btn>
            </v-card-actions>
        </v-card>
        <sales-order-expedition></sales-order-expedition>
    </v-dialog>
</template>

<style>
.vertical-center {
  margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.zalfa-dialog-item {
    margin: 12px !important;
    max-height: 95% !important;
}
.qo-detail-table table thead tr {
    height: auto
}
</style>
<script>
module.exports = {
    components : {
        "sales-order-expedition":httpVueLoader('./sales-order-expedition.vue')
    },

    data () {
        return {
            headers: [
                {
                    text: "#",
                    align: "center",
                    sortable: false,
                    width: "10%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "NAMA ITEM",
                    align: "left",
                    sortable: false,
                    width: "55%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },
                {
                    text: "QTY",
                    align: "center",
                    sortable: false,
                    width: "15%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                },,
                {
                    text: "SUBTOTAL",
                    align: "right",
                    sortable: false,
                    width: "15%",
                    class: "pa-2 zalfa-bg-purple lighten-3 white--text"
                }
            ]
        }
    },

    computed : {
        dialog : {
            get () { return this.$store.state.quickorder.dialog_quick },
            set (v) { this.$store.commit('quickorder/set_common', ['dialog_quick', v]) }
        },

        items () {
            return this.$store.state.quickorder.items
        },

        height () {
            return window.innerHeight * 0.95
        },

        details () {
            return this.$store.state.quickorder.details
        },

        cities () {
            return this.$store.state.quickorder.cities
        },

        selected_city : {
            get () { return this.$store.state.quickorder.selected_city },
            set (v) { this.$store.commit('quickorder/set_selected_city', v) }
        },

        search_city : {
            get () { return this.$store.state.quickorder.search_city },
            set (v) { this.$store.commit('quickorder/set_common', ['search_city', v]) }
        },

        selected_expedition () {
            return this.$store.state.quickorder.selected_expedition
        },

        selected_service () {
            return this.$store.state.quickorder.selected_service
        },

        total () {
            return this.$store.state.quickorder.total
        },

        exp_cost () {
            return this.$store.state.quickorder.courier_cost
        },

        cod_cost () {
            return 0
        },

        grand_total () {
            return parseFloat(this.total) + parseFloat(this.exp_cost) + parseFloat(this.cod_cost)
        },

        cust_name : {
            get () { return this.$store.state.quickorder.cust_name },
            set (v) { this.$store.commit('quickorder/set_common', ['cust_name', v]) }
        },

        cust_address : {
            get () { return this.$store.state.quickorder.cust_address },
            set (v) { this.$store.commit('quickorder/set_common', ['cust_address', v]) }
        },

        cust_postcode : {
            get () { return this.$store.state.quickorder.cust_postcode },
            set (v) { this.$store.commit('quickorder/set_common', ['cust_postcode', v]) }
        },

        cust_phone : {
            get () { return this.$store.state.quickorder.cust_phone },
            set (v) { this.$store.commit('quickorder/set_common', ['cust_phone', v]) }
        },

        loading_city () {
            return this.$store.state.quickorder.loading_city
        },

        btn_save_enable () {
            if (this.cust_name == '' || this.cust_address == '' || this.cust_phone == '')
                return false
            if (!this.selected_service)
                return false
            if (this.details.length < 1)
                return false
            return true
        }
    },

    methods : {
        one_money (x) {
            return window.one_money(x)
        },

        add (x) {
            let items = this.$store.state.quickorder.details
            let status = true

            for (let i in items)
                if (items[i].item_id == x.M_ItemID && items[i].is_packet == 'N') status = false

            if (status) {
                items.push({item_id:x.M_ItemID, item_name:x.M_ItemName, item_qty:1, item_price:x.M_PriceAmount, item_disc:0, item_discrp:x.M_PriceDiscTotal, item_subtotal:x.M_PriceTotal, item_weight:x.M_ItemWeight, is_packet:'N'})
                // this.dialog = false
                this.$store.commit('quickorder/set_details', items)
                // this.curr_item_name = x.M_ItemName
                // this.snackbar = true
            }
        },

        del (i) {
            let items = this.$store.state.quickorder.details
            items.splice(i,1)
            this.$store.commit('quickorder/set_details', items)
        },

        is_selected (i) {
            let items = this.$store.state.quickorder.details
            for (let item of items)
                if (item.item_id == i.M_ItemID)
                    return true
            return false
        },

        is_selected_class (i) {
            if (this.is_selected(i)) return 'cyan lighten-4'
            return ''
        },

        thr_search: _.debounce( function () {
            this.$store.dispatch("quickorder/search_city")
        }, 700),

        edit_expedition () {
            this.$store.commit('quickorder/set_common', ['dialog_expedition', true])
        },

        save () {
            this.$store.dispatch('quickorder/save')
        }
    },

    mounted () {
        this.$store.dispatch('quickorder/search_item')
    },

    watch : {
        search_city(val, old) {
            if (val == null || typeof val == 'undefined') val = ""
            if (val == old ) return
            if (this.$store.state.quickorder.search_status == 1 ) return  
            this.$store.commit("quickorder/set_common", ['search_city', val])
            this.thr_search()
      }
    }
}
</script>