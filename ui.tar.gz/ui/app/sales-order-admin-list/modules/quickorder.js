// 1 => LOADING
// 2 => DONE
// 3 => ERROR
import * as api from "./api_salesorder.js"
import { URL, one_token } from "../../assets/js/global.js"

export default {
    namespaced: true,
    state: {
        URL: URL,
        edit: false,
        search_status: 0,
        search_error_message: '',
        search: '',
        query: '',

        items: [],
        total_item: 0,
        selected_item: {},
        selected_items: [],

        details: [],
        selected_detail: null,

        expeditions: [],
        total_expedition: 0,
        selected_expedition: null,

        services: [],
        total_service: 0,
        selected_service: null,

        courier_cost: 0,
        weight_add: 0,
        weight_total: 0,
        total: 0,

        dialog_quick: true,
        cities: [],
        selected_city: null,
        search_city: '',
        loading_city: false,

        dialog_expedition: false,
        loading_service: false,

        cust_name: '',
        cust_address: '',
        cust_postcode: '',
        cust_phone: ''
    },
    mutations: {
        set_common(state, v) {
            let name = v[0]
            let val = v[1]
            if (typeof(val) == "string")
                eval(`state.${name} = "${val}"`)
            else
                eval(`state.${name} = ${val}`)
        },

        update_search_error_message(state, msg) {
            state.search_error_message = msg
        },

        update_search(state, search) {
            state.search = search
        },

        update_orders(state, data) {
            state.orders = data
        },

        set_selected_order(state, val) {
            state.selected_order = val
        },

        update_search_status(state, val) {
            state.search_status = val
        },

        update_total_order(state, val) {
            state.total_order = val
        },

        update_items(state, data) {
            for (let i in data) {
                if (data[i].L_SoDetailApproved == 'N')
                    data[i].L_SoDetailSubTotal = (data[i].L_SoDetailPrice - data[i].L_SoDetailDiscTotal) * data[i].L_SoDetailApprovedQty
            }
            state.items = data

            let t = 0
            for (let d of data)
                t += parseFloat(d.M_ItemWeight * d.L_SoDetailApprovedQty);
                
            let so = state.selected_order
            so.L_SoSubTotalWeight = t
            
            state.selected_order = so
            state.weight_total = parseFloat(t) + parseFloat(state.weight_add)
        },

        set_selected_item(state, val) {
            state.selected_item = val
        },

        set_expeditions(state, data) {
            state.expeditions = data
        },

        set_selected_expedition(state, val) {
            state.selected_expedition = val
        },

        set_total_expedition(state, v) {
            state.total_expedition = v
        },

        set_services(state, data) {
            state.services = data
        },

        set_selected_service(state, val) {
            state.selected_service = val
        },

        set_total_service(state, v) {
            state.total_service = v
        },

        set_selected_items(state, val) {
            state.selected_items = val
        },

        update_total_item(state, val) {
            state.total_item = val
        },

        set_details (state, v) {
            let total = 0
            let weight = 0
            for (let d of v) {
                total += parseFloat(d.item_subtotal)
                weight += parseFloat(d.item_weight * d.item_qty)
            }

            state.details = v
            state.total = total
            state.weight_total = weight
        },

        set_selected_detail (state, v) {
            state.selected_detail = v
        },

        set_cities (state, v) {
            state.cities = v
        },

        set_selected_city (state, v) {
            state.selected_city = v
        }
    },
    actions: {
        async save(context) {
            context.commit("update_search_status", 1)
            context.commit("set_dialog_progress", true, {root:true})
            try {
                let prm = {
                    order_id: 0,
                    expedition_id: context.state.selected_expedition.M_ExpeditionID,
                    service: context.state.selected_service.service,
                    courier_cost: context.state.courier_cost,
                    payment_id: 2, //context.state.selected_payment_id,
                    json_data: context.state.details,
                    is_dropship: "N", //context.state.is_dropship,
                    ds_customer_id: 0, //context.state.is_dropship == "Y" ? context.state.selected_ds_customer.M_CustomerID : 0,
                    cust_name: context.state.cust_name,
                    cust_address: context.state.cust_address,
                    cust_kelurahan_id: context.state.selected_city.kelurahan_id,
                    cust_postcode: context.state.cust_postcode,
                    cust_phone: context.state.cust_phone,
                    token: one_token()
                }

                let resp = await api.save_qo(prm)
                context.commit("set_dialog_progress", false, {root:true})
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    console.log(resp)
                    context.commit('set_common', ['dialog_quick', false])
                    context.dispatch('salesorder/search', null, {root:true})
                }
            } catch (e) {
                context.commit("set_dialog_progress", false, {root:true})
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },

        async search_item(context) {
            context.commit("update_search_status", 1)
            try {
                let prm = {}
                prm.token = one_token()
                let resp = await api.search_items(prm)
                
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")
                    let data = {
                        records: resp.data.records,
                        total: resp.data.total
                    }

                    context.commit("update_items", data.records)
                    context.commit("update_total_item", data.total)
                }
            } catch (e) {
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },

        async search_city(context) {
            context.commit("update_search_status", 1)
            context.commit('set_common', ['loading_city', true])
            try {
                let prm = {
                    token: one_token(),
                    search: context.state.search_city
                }

                let resp = await api.search_city(prm)

                context.commit('set_common', ['loading_city', false])
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    context.commit("set_cities", resp.data.records)
                }
            } catch (e) {
                context.commit('set_common', ['loading_city', false])
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_expedition(context) {
            context.commit("update_search_status", 1)
            try {
                let prm = {
                    token: one_token()
                }

                let resp = await api.search_expedition(prm)
                
                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")

                    let data = {
                        records: resp.data.records,
                        total: resp.data.total
                    }

                    context.commit("set_expeditions", data.records)
                    context.commit("set_total_expedition", data.total)
                }
            } catch (e) {
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        },
        
        async search_service(context) {
            context.commit("update_search_status", 1)
            context.commit('set_common', ['loading_service', true])
            try {
                let prm = {
                    token: one_token(),
                    to: context.state.selected_city.kecamatan_id,
                    courier: context.state.selected_expedition.M_ExpeditionROCode,
                    weight: context.state.weight_total
                }

                let resp = await api.search_service(prm)
                context.commit('set_common', ['loading_service', false])

                if (resp.status != "OK") {
                    context.commit("update_search_status", 3)
                    context.commit("update_search_error_message", resp.message)
                } else {
                    context.commit("update_search_status", 2)
                    context.commit("update_search_error_message", "")
                    
                    let data = JSON.parse(resp.data)

                    // context.commit('set_common', ['courier_cost', context.state.selected_order.L_SoExpCost])
                    context.commit("set_services", data.rajaongkir.results[0].costs)
                    // if (context.state.edit) {
                    //     for (let svc of context.state.services) {
                    //         if (svc.service == context.state.selected_order.L_SoExpService) {
                    //             context.commit('set_selected_service', svc)
                    //         }
                    //     }
                    // }
                    // context.commit('set_common', ['courier_cost', context.state.selected_service.cost[0].value])
                }
            } catch (e) {
                context.commit('set_common', ['loading_service', false])
                context.commit("update_search_status", 3)
                context.commit("update_search_error_message", e.message)
            }
        }
    }
}