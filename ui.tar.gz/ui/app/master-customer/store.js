// State
//  data ...
// Mutations
//
//
// Actions
import customer from "./modules/customer.js";
import customer_new from "./modules/customer_new.js";
import system from "../assets/js/system.js";

export const store = new Vuex.Store({
    state : {
        dialog_delete: false,
        dialog_progress: false
    },

    mutations : {
        set_dialog_delete (state, v) {
            state.dialog_delete = v
        },

        set_dialog_progress (state, v) {
            state.dialog_progress = v
        }
    },

    modules : {
        customer: customer,
        customer_new: customer_new,
         system: system
    }
});
