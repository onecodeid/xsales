---
home: true
heroImage: https://raw.githubusercontent.com/apertureless/vue-chartjs/main/website/src/images/vue-chartjs.png
actionText: Começar →
actionLink: /pt-br/guide/
features:
- title: Fácil
  details: Fácil para ambos, iniciantes e profissionais 🙌
- title: Extensível
  details: Simples de usar, fácil de estender 💪
- title: Poderoso
  details: Com todo o poder do chart.js 💯
footer: MIT Licenciado | Copyright © 2018-presente Jakub Juszczak
---
