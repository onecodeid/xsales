---
home: true
heroImage: https://raw.githubusercontent.com/apertureless/vue-chartjs/main/website/src/images/vue-chartjs.png
actionText: Начать →
actionLink: /ru/guide/
features:
- title: Простота
  details: Просто как для новичков, так и для профессионалов 🙌
- title: Расширяемость
  details: Просто использовать, легко расширять 💪
- title: Могущество
  details: С полной силой chart.js 💯
footer: MIT Licensed | Copyright © 2018-present Jakub Juszczak
---
