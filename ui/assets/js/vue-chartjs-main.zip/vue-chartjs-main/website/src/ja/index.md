---
home: true
heroImage: https://raw.githubusercontent.com/apertureless/vue-chartjs/main/website/src/images/vue-chartjs.png
actionText: 初めに →
actionLink: /ja/guide/
features:
- title: 簡単
  details: 初心者にもプロにも簡単に始められる 🙌
- title: 拡張性
  details: シンプルに使えて、拡張も簡単 💪
- title: 強力
  details: chart.jsのフルパワーを持っている 💯
footer: MIT Licensed | Copyright © 2018-present Jakub Juszczak
---
