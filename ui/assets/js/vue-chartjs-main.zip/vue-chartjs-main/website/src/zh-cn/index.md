---
home: true
heroImage: https://raw.githubusercontent.com/apertureless/vue-chartjs/main/website/src/images/vue-chartjs.png
actionText: 起步 →
actionLink: /zh-cn/guide/
features:
- title: 简单
  details: 适合初学者和专业人士 🙌
- title: 扩展性
  details: 使用简单, 扩展方便 💪
- title: 强大
  details: 拥有 chart.js 的全部功能 💯
footer: MIT Licensed | Copyright © 2018-present Jakub Juszczak
---
