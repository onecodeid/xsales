import { configureActions } from '@storybook/addon-actions'

configureActions({
  depth: 5
})
