import { Chart } from './chart.js'
import {
  createTypedChart,
  Bar,
  Doughnut,
  Line,
  Pie,
  PolarArea,
  Radar,
  Bubble,
  Scatter
} from './typedCharts.js'

export type { ChartProps, ChartComponentRef } from './types.js'
export {
  getDatasetAtEvent,
  getElementAtEvent,
  getElementsAtEvent
} from './utils.js'
export {
  Chart,
  createTypedChart,
  Bar,
  Doughnut,
  Line,
  Pie,
  PolarArea,
  Radar,
  Bubble,
  Scatter
}
