<?php

class MY_Controller extends CI_Controller
{
    public $sys_input;
    public $is_login;

    public $SECRET_KEY = "--one-secret-1924";
    public $RO_KEY = "bd505a3f96a95686f7ac2775e43a37fa";
    public $RO_URL = "https://pro.rajaongkir.com/api/";

    public $IPAYMU_KEY = "HWuK5V6Q9GRbAzoCG2tDbfbr4OBxk.";
    public $IPAYMU_URL = "https://my.ipaymu.com/api/";

    function __construct()
    {
        parent::__construct();

        $this->load->library("Jwt");
        $this->load->database();

        $this->sys_input = json_decode($this->input->raw_input_stream, true);
        if (! $this->sys_input ) {
            if ( count($this->input->post()) > 0 ) {
                $this->sys_input = $this->input->post();
            } else {
                $this->sys_input = $this->input->get();
            }
        }

        // CHECK USER TOKEN
        try {
            $prm  = $this->sys_input;
            if (! isset($prm["token"])) {
               $this->is_login = false;
            } else {
               $user = JWT::decode($prm["token"],$this->SECRET_KEY,true);
               unset($this->sys_input["token"]);
               $user = json_decode(json_encode($user),true);
               if ($user["user_id"] > 0 ) {
                  $this->is_login = true;
               }
               $this->sys_user = $user;
               $query = $this->db->query("update s_user SET S_UserLastLogin = now() WHERE S_UserID = ?", array($user["user_id"]));
               if (!$query) {
                 $message = $this->db->error();
                 $this->sys_error($message);
                 exit;
               }
               //update last accessed 
            }
        } catch(Exception $e) {
            $this->is_login = false;
        }
    }

    public function sys_ok($data) {
        echo json_encode(
           array(
              "status" => "OK",
              "data" => $data
           )
        );
    }

    public function sys_error($message) {
        echo json_encode(
           array(
              "status" => "ERR",
              "message" => $message
           )
        );
    }
}

class RPT_Controller extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->library('pdf');
    }

    public static function my_header($me, $title = 'anu', $desc = 'asd', $orientation = 'P')
    {
        $width = $orientation == 'P' ? 19 : 28;
        $cp = 'me->company';
        $me->pdf->SetFont('Arial', 'B', 13);
        $gy = $me->pdf->GetY();

        $me->pdf->Image(base_url() . '/assets/images/logo-1-1.png', 0.8, 0.7, 3);

        $me->pdf->SetY($gy+0.5);
        $me->pdf->SetFont('Arial', '', 18);
        $me->pdf->Cell($width, 0.5, $title, '', 1, 'R');
        
        $me->pdf->SetFont('Arial', '', 11);
        $me->pdf->Cell($width, 0.7, $desc, 'B', 1, 'R');
        $me->pdf->Ln(1);
    }
}


?>