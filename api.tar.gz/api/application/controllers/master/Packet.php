<?php

class Packet extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('master/m_packet');
    }

    function search()
    {
        $r = $this->m_packet->search(['packet_name'=>'%']);
        $this->sys_ok($r);
    }

    function search_w_price()
    {
        $r = $this->m_packet->search_w_price(['item_name'=>'%', 'customer_level'=>1]);
        $this->sys_ok($r);
    }

    function save()
    {
        $id = 0;
        if (isset($this->sys_input['packet_id']))
            $id = $this->sys_input['packet_id'];

        $r = $this->m_packet->save( $this->sys_input, $id );
        echo json_encode($r);
    }

    function del()
    {
        $r = $this->m_packet->del( $this->sys_input );
        $this->sys_ok($r);
    }
}

?>