<?php

class Customerlevel extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('master/m_customerlevel');
    }

    function index()
    {
        echo "Customer Level API";
        return;
    }

    function search()
    {
        $r = $this->m_customerlevel->search(['customer_level_name'=>'%']);
        $this->sys_ok($r);
    }
}

?>