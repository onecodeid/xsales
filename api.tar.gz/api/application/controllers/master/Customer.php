<?php

class Customer extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('master/m_customer');
    }

    function index()
    {
        return;
    }

    function search()
    {
        $r = $this->m_customer->search(['customer_name'=>'%', 
                                    'page'=>$this->sys_input['page'],
                                    'level'=>$this->sys_input['level'],
                                    'city'=>$this->sys_input['city'],
                                    'province'=>$this->sys_input['province'],
                                    'user_id'=>$this->sys_user['user_id']]);
        $r['user'] = $this->sys_user;
        $this->sys_ok($r);
    }

    function search_autocomplete()
    {
        $r = $this->m_customer->search_autocomplete([
            'customer_name'=>'%'.$this->sys_input['search'].'%', 
            'user_id'=>$this->sys_user['user_id']]);
        $r['user'] = $this->sys_user;

        $this->load->model('sales/l_so');
        foreach ($r['records'] as $k => $v)
        {
            $x = $this->l_so->search_top_by_customer(['search'=>'%','customer_id'=>$v['M_CustomerID']]);
            $r['records'][$k]['orders'] = $x['records'];
        }

        $this->sys_ok($r);
    }

    function save()
    {
        $this->sys_input['user_id'] = $this->sys_user['user_id'];
        if (isset($this->sys_input['customer_id']))
            $r = $this->m_customer->edit( $this->sys_input );
        else
            $r = $this->m_customer->save( $this->sys_input );

        echo json_encode($r);
    }

    function del()
    {
        $r = $this->m_customer->del( $this->sys_input['customer_id'] );
        $this->sys_ok($r);
    }

    function revoke_user()
    {
        $r = $this->m_customer->revoke_user( $this->sys_input['customer_id'] );
        $this->sys_ok($r);
    }

    function get_one()
    {
        $r = $this->m_customer->get_one($this->sys_input['customer_id']);
        $this->sys_ok($r);
    }
}

?>