<?php

class So extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('sales/l_so');
    }

    function save()
    {
        $r = $this->l_so->save($this->sys_input);

        $this->sys_ok($r);
    }

    function save_qo()
    {
        $r = $this->l_so->save_qo($this->sys_input, $this->sys_user['user_id']);

        $this->sys_ok($r);
    }

    function search()
    {
        $q = [
            'search' => '%'.$this->sys_input['search'].'%',
            'sdate' => date('Y-m-d 00:00:00', strtotime($this->sys_input['sdate'])),
            'edate' => date('Y-m-d 23:59:59', strtotime($this->sys_input['edate']))
        ];
        $r = $this->l_so->search($q);

        $this->sys_ok($r);
    }

    function approve()
    {
        $d = ['json_data'=>$this->sys_input['json_data'], 
                'header_data'=>
                    [
                        'weight_add'=>$this->sys_input['weight_add'],
                        'service'=>$this->sys_input['service'],
                        'cost'=>$this->sys_input['cost'],
                        'expedition_id'=>$this->sys_input['expedition_id']
                    ],
                'uid'=>$this->sys_user['user_id']];
        $r = $this->l_so->approve($d);

        $this->sys_ok($r);
    }
}

?>