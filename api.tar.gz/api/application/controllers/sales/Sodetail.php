<?php

class Sodetail extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('sales/l_sodetail');
    }

    // function save()
    // {
    //     $r = $this->l_so->save($this->sys_input);

    //     $this->sys_ok($r);
    // }

    function search()
    {
        $q = [
            'search' => '%'.$this->sys_input['search'].'%',
            'order_id' => $this->sys_input['order_id']
        ];
        $r = $this->l_sodetail->search($q);

        $this->sys_ok($r);
    }
}

?>