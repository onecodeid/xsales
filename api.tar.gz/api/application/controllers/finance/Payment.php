<?php

class Payment extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('finance/f_payment');
    }

    function search()
    {
        $q = [
            'search' => '%'.$this->sys_input['search'].'%',
            'sdate' => date('Y-m-d 00:00:00', strtotime($this->sys_input['sdate'])),
            'edate' => date('Y-m-d 23:59:59', strtotime($this->sys_input['edate']))
        ];
        $r = $this->f_payment->search($q);

        $this->sys_ok($r);
    }

    function confirm()
    {
        $r = $this->f_payment->confirm($this->sys_input['payment_id'], $this->sys_user['user_id']);
        if ($r->status == "OK")
            $this->sys_ok($r->data);
        else
            $this->sys_error($r->message);
    }
}

?>