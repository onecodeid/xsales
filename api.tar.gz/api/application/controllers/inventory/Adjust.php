
<?php

class Adjust extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('inventory/i_adjust');
    }

    function index()
    {
        return;
    }

    function search()
    {
        $r = $this->i_adjust->search(
            ['search'=>'%'.$this->sys_input['search'].'%',
            'sdate'=>date('Y-m-d 00:00:00', strtotime($this->sys_input['sdate'])),
            'edate'=>date('Y-m-d 23:59:59', strtotime($this->sys_input['edate']))]);
        $this->sys_ok($r);
    }

    function save()
    {
        $this->sys_input['uid'] = 1;
        $r = $this->i_adjust->save( $this->sys_input );

        if ($r->status == "OK")
            $this->sys_ok($r);
        else
            $this->sys_error($r);
    }

    // function del()
    // {
    //     $r = $this->m_customer->del( $this->sys_input );
    //     $this->sys_ok($r);
    // }
}

?>