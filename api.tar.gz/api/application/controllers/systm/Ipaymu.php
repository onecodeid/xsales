<?php

class Ipaymu extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        return;
    }

    function balance_check()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->IPAYMU_URL."saldo?key=".$this->IPAYMU_KEY."&format=json",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
        echo "cURL Error #:" . $err;
        } else {
            $d = json_decode($response);
            if ($d->Status == "200")
                $this->sys_ok($d->Saldo);
            else
                $this->sys_error('0');
        }
        
    }
}

?>