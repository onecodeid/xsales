<?php

class User extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('system/s_user');
    }

    function index()
    {
        return;
    }

    function search()
    {
        $r = $this->s_user->search(['search'=>'%', 'gid'=>$this->sys_input['group_id']]);
        $this->sys_ok($r);
    }

    function login()
    {
        $r = $this->s_user->login($this->sys_input['username'],
                                $this->sys_input['password']);

        if ($r->status == "OK")
        {
            $user = (array) json_decode($r->data);
            $user['ip'] = $_SERVER['REMOTE_ADDR'];
            $user['agent'] = $_SERVER['HTTP_USER_AGENT'];
            $token  = JWT::encode($user, $this->SECRET_KEY);
            
            $data = array(
                "user" => $user,
                "token" => $token
            );
                        
            $this->sys_ok($data);    
        }
        else
        {
            $this->sys_error($r->message);
        }
    }

    function logout() 
    {
        $prm = $this->sys_input;
        try 
        {
            $this->s_user->logout($this->sys_user['user_id']);
            $this->sys_ok("OK");
        } 
        catch(Exception $exc) 
        {
            $message = $exc->getMessage();
            $this->sys_error($message);
        }
    }

    function save_profile()
    {
        $r = $this->s_user->save_profile( $this->sys_input, $this->sys_user['user_id'] );
        echo json_encode($r);
    }

    function get_profile ()
    {
        $r = $this->s_user->get_profile($this->sys_user['user_id']);
        $this->sys_ok($r);
    }

    function save_password ()
    {
        $d = $this->sys_input;
        $d['user_name'] = $this->sys_user['user_name'];
        $r = $this->s_user->save_password($d);

        if ($r->status == 'OK')
            $this->sys_ok(true);
        else
            $this->sys_error($r->message);
    }

    function save ()
    {
        $d = $this->sys_input;
        $r = $this->s_user->save($d);

        if ($r->status == 'OK')
            $this->sys_ok(true);
        else
            $this->sys_error($r->message);
    }

    function check ()
    {
        $d = $this->sys_input;
        $r = $this->s_user->check($d);

        if ($r->status == 'OK')
            $this->sys_ok(true);
        else
            $this->sys_error($r->message);
    }

    function del ()
    {
        $d = $this->sys_input;
        $r = $this->s_user->del($d);

        $this->sys_ok(true);        
    }
}

?>