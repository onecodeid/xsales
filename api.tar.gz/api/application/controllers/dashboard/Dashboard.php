<?php

class Dashboard extends MY_Controller
{
    function __construct()
    {
        parent::__construct();

        $this->load->model('dashboard/d_dashboard');
    }

    function get_customer_total_by_admin()
    {
        $r = $this->d_dashboard->get_customer_total_by_admin($this->sys_user['user_id']);
        $this->sys_ok($r);
    }
}
?>