<?php

class R_report extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = "r_report";
        $this->table_key = "R_ReportID";
    }

    function search_groups()
    {
        $r = $this->db->query("SELECT a.*, CONCAT('[', GROUP_CONCAT(JSON_OBJECT('report_id', R_ReportID, 'report_name', R_ReportName, 'report_code', R_ReportCode, 'report_desc', R_ReportDesc, 'report_url', R_ReportUrl) SEPARATOR ','), ']') childs FROM
                            (SELECT a.R_ReportID report_id, a.R_ReportName report_name, 
                            a.R_ReportLeft report_left, a.R_ReportRight report_right, a.R_ReportIcon report_icon, a.R_ReportCode report_code,
                            a.R_ReportDesc report_desc
                            FROM r_report a
                            LEFT JOIN r_report b ON b.R_ReportLeft < a.R_ReportLeft AND b.R_ReportRight > a.R_ReportRight AND b.R_ReportIsActive = 'Y'
                            WHERE a.R_ReportIsActive = 'Y'
                            GROUP BY a.R_ReportID
                            HAVING COUNT(b.R_ReportID) < 1
                            ORDER BY a.R_ReportLeft) a
                            JOIN r_report c ON report_left < R_ReportLeft AND report_right > R_ReportRight AND R_ReportIsActive = 'Y'
                            GROUP BY report_id
                            ");
        if ($r)
        {               
            $r = $r->result_array();
            foreach ($r as $k => $v)
                $r[$k]['childs'] = json_decode($v['childs']);
            return ['records'=>$r];
        }

        return ['records'=>[]];
    }

    // Report Detail Penjualan Per Admin
    function One_sales_002($uid, $sdate, $edate)
    {
        $r = $this->GetMultipleQueryResult("CALL `sp_r_sales_002`('{$sdate}', '{$edate}', '{$uid}')", 2);
        return $r;
    }

    // Report Invoice Penjualan
    function One_iv_001($id)
    {
        $r = $this->GetMultipleQueryResult("CALL `sp_r_iv_001`('{$id}')", 2);
        return $r;
    }

    // Report Fee / Komisi Per Admin
    function One_fin_001($uid, $sdate, $edate)
    {
        $r = $this->GetMultipleQueryResult("CALL `sp_r_fin_001`('{$uid}', '{$sdate}', '{$edate}')", 2);
        return $r;
    }

    // Report Laporan Customer
    function One_master_001($uid, $provinceid = 0, $cityid = 0)
    {
        $r = $this->GetMultipleQueryResult("CALL `sp_r_master_001`('{$uid}', '{$provinceid}', '{$cityid}')", 2);
        return $r;
    }
}

?>