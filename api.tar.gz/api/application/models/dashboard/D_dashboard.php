<?php
class D_dashboard extends MY_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function get_customer_total_by_admin ($uid)
    {
        $r = $this->db->query("CALL sp_dashboard_stat_customer(?)", [$uid])
                    ->row();
        return $r;
    }
}
?>

