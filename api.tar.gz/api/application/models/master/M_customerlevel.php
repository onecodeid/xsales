<?php

class M_customerlevel extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = "m_customerlevel";
        $this->table_key = "M_CustomerLevelID";
    }

    function search( $d )
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT *
                FROM `{$this->table_name}`
                WHERE `M_CustomerLevelName` LIKE ?
                AND `M_CustomerLevelIsActive` = 'Y'", [$d['customer_level_name']]);
        if ($r)
        {
            $r = $r->result_array();
            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            WHERE `M_CustomerLevelName` LIKE ?
                AND `M_CustomerLevelIsActive` = 'Y'", [$d['customer_level_name']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }
}

?>