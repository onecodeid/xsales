<?php

class M_packet extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = "m_packet";
        $this->table_key = "M_PacketID";
    }

    function search( $d )
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT *
                FROM `{$this->table_name}`
                WHERE `M_PacketName` LIKE ?
                AND `M_PacketIsActive` = 'Y'", [$d['packet_name']]);
        if ($r)
        {
            $r = $r->result_array();
            // PRICES
            // $this->load->model('master/m_price');
            // foreach ($r as $k => $v)
            // {
            //     $x = $this->m_price->search_by_packet(['packet_id'=>$v['M_PacketID']]);
            //     $r[$k]['prices'] = $x['records'];
            // }

            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            WHERE `M_PacketName` LIKE ?
            AND `M_PacketIsActive` = 'Y'", [$d['packet_name']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }

    function save ( $d, $id = 0 )
    {
        $x = [  'M_PacketName' => $d['packet_name'],
                'M_PacketCode' => $d['packet_code']];

        if ($id == 0)
        {
            $this->db->insert( $this->table_name, $x );
            $id = $this->db->insert_id();
        }
        else
        {
            $this->db->set($x)
                    ->where('M_PacketID', $id)
                    ->update( $this->table_name );
        }

        return ["status"=>"OK", "data"=>$id, "q"=>$this->db->last_query()];
    }

    function del ($id)
    {
        $this->db->set('M_PacketIsActive', 'N')
                ->where('M_PacketID', $this->sys_input['id'])
                ->update($this->table_name);

        // DEL DETAIL
        $this->db->set('M_PacketDetailIsActive', 'N')
                ->where('M_PacketDetailM_PacketID', $this->sys_input['id'])
                ->update('m_packetdetail');

        // DEL PRICE
        $this->db->set('M_PacketPriceIsActive', 'N')
                ->where('M_PacketPriceM_PacketID', $this->sys_input['id'])
                ->update('m_packetprice');

        return true;
    }

    function search_w_price( $d )
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT *
                FROM `{$this->table_name}`
                JOIN (
                    SELECT M_PacketPriceM_PacketID packet_id, SUM(M_PacketPriceNormal) price_normal,
                        SUM(M_PacketPriceSale) price_sale, GROUP_CONCAT(M_ItemName SEPARATOR ', ') item_names
                    FROM m_packetprice
                    JOIN m_item ON M_PAcketPriceM_ItemID = M_ItemID
                    WHERE M_PacketPriceIsActive = 'Y' AND M_PacketPriceM_CustomerLevelID = ?
                    GROUP BY M_PacketPriceM_PacketID
                ) packet_price ON packet_id = M_PacketID
                WHERE `M_PacketName` LIKE ?
                AND `M_PacketIsActive` = 'Y'", [$d['customer_level'], $d['item_name']]);
        if ($r)
        {
            $r = $r->result_array();
            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            JOIN (
                    SELECT M_PacketPriceM_PacketID packet_id, SUM(M_PacketPriceNormal) price_normal,
                        SUM(M_PacketPriceSale) price_sale, GROUP_CONCAT(M_ItemName SEPARATOR ', ') item_names
                    FROM m_packetprice
                    JOIN m_item ON M_PAcketPriceM_ItemID = M_ItemID
                    WHERE M_PacketPriceIsActive = 'Y' AND M_PacketPriceM_CustomerLevelID = ?
                    GROUP BY M_PacketPriceM_PacketID
                ) packet_price ON packet_id = M_PacketID
            WHERE `M_PacketName` LIKE ?
            AND `M_PacketIsActive` = 'Y'", [$d['customer_level'], $d['item_name']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }
}

?>