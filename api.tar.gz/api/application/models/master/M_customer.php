<?php

class M_customer extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = "m_customer";
        $this->table_key = "M_CustomerID";
    }

    function search( $d )
    {
        $limit = isset($d['limit']) ? $d['limit'] : 10;
        $offset = ($d['page'] - 1) * $limit;
        $l = ['records'=>[], 'total'=>0, 'total_page'=>1];

        $r = $this->db->query(
                "SELECT m_customer.*, M_CityName, M_ProvinceName, kelurahan_id, full_address,
                M_ProvinceID, M_CityID, M_DistrictID, M_KelurahanID, M_CustomerLevelID,
                M_CustomerLevelCode, M_CustomerLevelName,
                IFNULL(S_UserCustomerID, 0) user_customer_id, S_UserCustomerUsername user_customer_username
                FROM `{$this->table_name}`
                JOIN s_user ON S_UserID = ?
                JOIN s_usergroup ON S_UserS_UserGroupID = S_UserGroupID
                JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
                    AND ((M_CustomerLevelID = ? AND ? <> 0) OR (? = 0))
                LEFT JOIN m_kelurahan ON M_CustomerM_KelurahanID = M_KelurahanID
                LEFT JOIN m_district ON M_KelurahanM_DistrictID = M_DistrictID
                LEFT JOIN m_city ON m_districtM_CityID = M_CityID
                LEFT JOIN m_province ON M_CityM_ProvinceID = M_ProvinceID
                LEFT JOIN v_cities ON M_CustomerM_KelurahanID = kelurahan_id
                LEFT JOIN s_usercustomer ON S_UserCustomerM_CustomerID = M_CustomerID AND S_UserCustomerIsActive = 'Y'
                WHERE `M_CustomerName` LIKE ?
                AND `M_CustomerIsActive` = 'Y'
                AND ((M_ProvinceID = ? AND ? <> 0) OR ? = 0)
                AND ((M_CityID = ? AND ? <> 0) OR ? = 0)
                AND ((M_CustomerUserID = ? AND S_UserGroupCode <> 'Z.GROUP.01') OR S_UserGroupCode = 'Z.GROUP.01')
                LIMIT {$limit} OFFSET {$offset}", [$d['user_id'], $d['level'], $d['level'], $d['level'], $d['customer_name'],
                                                    $d['province'], $d['province'], $d['province'], $d['city'], $d['city'], $d['city'], $d['user_id']]);
        if ($r)
        {
            $r = $r->result_array();
            foreach ($r as $k => $v)
            {
                $q = $this->db->query("SELECT fn_address_kelurahan(?) as x", [$v['M_CustomerM_KelurahanID']])->row();
                $r[$k]['address_kelurahan'] = $q->x;

                $q = $this->db->query("SELECT fn_master_customer_referrer(?) as x", [$v['M_CustomerID']])->row();
                $r[$k]['referrer'] = json_decode($q->x);
            }
            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            JOIN s_user ON S_UserID = ?
                JOIN s_usergroup ON S_UserS_UserGroupID = S_UserGroupID
            JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
                    AND ((M_CustomerLevelID = ? AND ? <> 0) OR (? = 0))
            LEFT JOIN m_kelurahan ON M_CustomerM_KelurahanID = M_KelurahanID
            LEFT JOIN m_district ON M_KelurahanM_DistrictID = M_DistrictID
            LEFT JOIN m_city ON m_districtM_CityID = M_CityID
            LEFT JOIN m_province ON M_CityM_ProvinceID = M_ProvinceID
            LEFT JOIN v_cities ON M_CustomerM_KelurahanID = kelurahan_id
            WHERE `M_CustomerName` LIKE ?
            AND `M_CustomerIsActive` = 'Y'
            AND ((M_ProvinceID = ? AND ? <> 0) OR ? = 0)
                AND ((M_CityID = ? AND ? <> 0) OR ? = 0)
                AND ((M_CustomerUserID = ? AND S_UserGroupCode <> 'Z.GROUP.01') OR S_UserGroupCode = 'Z.GROUP.01')", [$d['user_id'], $d['level'], $d['level'], $d['level'], $d['customer_name'],
                                                    $d['province'], $d['province'], $d['province'], $d['city'], $d['city'], $d['city'], $d['user_id']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
            $l['total_page'] = ceil($r->row()->n / $limit);
        }
            
        return $l;
    }

    function save ( $d )
    {
        $r = $this->db->set('M_CustomerName', $d['customer_name'])
                    ->set('M_CustomerAddress', $d['customer_address'])
                    ->set('M_CustomerPhone', $d['customer_phone'])
                    ->set('M_CustomerNote', $d['customer_note'])
                    ->set('M_CustomerM_CustomerLevelID', $d['customer_level_id'])
                    ->set('M_CustomerM_KelurahanID', $d['customer_kelurahan_id'])
                    ->set('M_CustomerUserID', $d['user_id'])
                    ->insert( $this->table_name );
        $id = $this->db->insert_id();

        if ($r)
        {
            $x = null;
            if ($d['user_customer'] == 'Y')
            {
                $pwd = md5($this->pass_prefix . $d['user_customer_password'] . $this->pass_suffix);
                $x = $this->db->query("CALL sp_system_user_customer_create(?, ?, ?)", [$id, $d['user_customer_username'], $pwd])
                    ->row();
                $this->clean_mysqli_connection($this->db->conn_id);
            }
            

            return ["status"=>"OK", "data"=>$id, "user"=>$x];
        }

        return ["status"=>"ERR"];
    }

    function edit ( $d )
    {
        $r = $this->db->set('M_CustomerName', $d['customer_name'])
                    ->set('M_CustomerAddress', $d['customer_address'])
                    ->set('M_CustomerPhone', $d['customer_phone'])
                    ->set('M_CustomerNote', $d['customer_note'])
                    ->set('M_CustomerM_CustomerLevelID', $d['customer_level_id'])
                    ->set('M_CustomerM_KelurahanID', $d['customer_kelurahan_id'])
                    ->where('M_CustomerID', $d['customer_id'])
                    ->update( $this->table_name );
        if ($r)
        {
            if ($d['user_customer'] == 'Y' && $d['user_customer_password'] != "")
            {
                $pwd = md5($this->pass_prefix . $d['user_customer_password'] . $this->pass_suffix);
                $x = $this->db->query("CALL sp_system_user_customer_create(?, ?, ?)", [$d['customer_id'], $d['user_customer_username'], $pwd])
                    ->row();
                $this->clean_mysqli_connection($this->db->conn_id);
            }

            return ["status"=>"OK", "data"=>$d['customer_id']];
        }

        return ["status"=>"ERR"];
    }

    function del ($id)
    {
        $this->db->set('M_CustomerIsActive', 'N')
                ->where('M_CustomerID', $id)
                ->update($this->table_name);

        return true;
    }

    function revoke_user ($id)
    {
        $this->db->set('S_UserCustomerIsActive', 'N')
                ->where('S_UserCustomerM_CustomerID', $id)
                ->update('s_usercustomer');

        return true;
    }

    function get_one ($id)
    {
        $r = $this->db->select('M_CustomerName customer_name, M_CustomerAddress customer_address,
                                M_KelurahanName kelurahan_name, M_DistrictName district_name,
                                M_CityName city_name, M_ProvinceName province_name,
                                M_CustomerLevelName', false)
                    ->join('m_kelurahan', 'M_KelurahanID = M_CustomerM_KelurahanID')
                    ->join('m_district', 'M_DistrictID = M_KelurahanM_DistrictID')
                    ->join('m_city', 'M_CityID = M_DistrictM_City')
                    ->join('m_province', 'M_ProvinceID = M_CityM_ProvinceID')
                    ->join('m_customerlevel', 'M_CustomerM_CustomerLevelID = M_CustomerLevelID')
                    ->where('M_CustomerID', $id)
                    ->get($this->table_name)
                    ->row();
        return $r;
    }

    function search_autocomplete( $d )
    {
        $limit = 50;
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT m_customer.*, M_CityName, M_ProvinceName, kelurahan_id, full_address,
                    M_ProvinceID, M_CityID, M_DistrictID, M_KelurahanID, M_CustomerLevelID,
                    M_CustomerLevelName
                FROM `{$this->table_name}`
                JOIN s_user ON S_UserID = ?
                JOIN s_usergroup ON S_UserS_UserGroupID = S_UserGroupID
                JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
                LEFT JOIN m_kelurahan ON M_CustomerM_KelurahanID = M_KelurahanID
                LEFT JOIN m_district ON M_KelurahanM_DistrictID = M_DistrictID
                LEFT JOIN m_city ON m_districtM_CityID = M_CityID
                LEFT JOIN m_province ON M_CityM_ProvinceID = M_ProvinceID
                LEFT JOIN v_cities ON M_CustomerM_KelurahanID = kelurahan_id
                WHERE `M_CustomerName` LIKE ? 
                AND ((M_CustomerUserID = ? AND S_UserGroupCode <> 'Z.GROUP.01') OR S_UserGroupCode = 'Z.GROUP.01')
                AND `M_CustomerIsActive` = 'Y'
                LIMIT {$limit}", [$d['user_id'], $d['customer_name'], $d['user_id']]);
        if ($r)
        {
            $r = $r->result_array();
            foreach ($r as $k => $v)
            {
                $q = $this->db->query("SELECT fn_address_kelurahan(?) as x", [$v['M_CustomerM_KelurahanID']])->row();
                $r[$k]['address_kelurahan'] = $q->x;
            }
            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
            JOIN s_user ON S_UserID = ?
            JOIN s_usergroup ON S_UserS_UserGroupID = S_UserGroupID
            WHERE `M_CustomerName` LIKE ? 
            AND ((M_CustomerUserID = ? AND S_UserGroupCode <> 'Z.GROUP.01') OR S_UserGroupCode = 'Z.GROUP.01')
            AND `M_CustomerIsActive` = 'Y'", [$d['user_id'], $d['customer_name'], $d['user_id']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }
}

?>