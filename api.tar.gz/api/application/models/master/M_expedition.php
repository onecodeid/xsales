<?php

class M_expedition extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = "m_expedition";
        $this->table_key = "M_ExpeditionID";
    }

    function search( $d )
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT *
                FROM `{$this->table_name}`
                WHERE `M_ExpeditionName` LIKE ?
                AND `M_ExpeditionIsActive` = 'Y'", [$d['expedition_name']]);
        if ($r)
        {
            $r = $r->result_array();
            // // PRICES
            // $this->load->model('master/m_price');
            // foreach ($r as $k => $v)
            // {
            //     $x = $this->m_price->search_by_item(['item_id'=>$v['M_ExpeditionID']]);
            //     $r[$k]['prices'] = $x['records'];
            // }

            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            WHERE `M_ExpeditionName` LIKE ?
            AND `M_ExpeditionIsActive` = 'Y'", [$d['expedition_name']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }
}

?>