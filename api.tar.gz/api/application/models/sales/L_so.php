<?php

class L_So extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = 'l_so';
        $this->table_key = 'L_SoID';
    }

    function save($inp)
    {
        $r = $this->db->query("CALL sp_so_save(?, ?, ?)", [$inp['order_id'], $inp['customer_id'], json_encode($inp['json_data'])])
                    ->row();
        $this->clean_mysqli_connection($this->db->conn_id);

        $r->msg = $this->db->last_query();
        return $r;
    }

    function save_qo($inp, $uid)
    {
        $hdata = json_encode([
            'expedition_id' => $inp['expedition_id'],
            'service' => $inp['service'],
            'courier_cost' => $inp['courier_cost'],
            'payment_id' => $inp['payment_id'],
            'is_dropship' => $inp['is_dropship'],
            'ds_customer_id' => $inp['ds_customer_id']
        ]);

        $cdata = json_encode([
            'cust_name' => $inp['cust_name'],
            'cust_address' => $inp['cust_address'],
            'cust_postcode' => $inp['cust_postcode'],
            'cust_phone' => $inp['cust_phone'],
            'cust_kelurahan_id' => $inp['cust_kelurahan_id']
        ]);

        $r = $this->db->query("CALL sp_so_qo_save(?, ?, ?, ?, ?)", [$inp['order_id'], $cdata, $hdata, json_encode($inp['json_data']), $uid])
                    ->row();
        $this->clean_mysqli_connection($this->db->conn_id);

        $r->msg = $this->db->last_query();
        return $r;
    }

    function search( $d )
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT L_SoID, L_SoNumber, L_SoDate, L_SoIsDS, L_SoTotalUniqueQty, L_SoTotalQty,
                    L_SoSubTotalWeight, L_SoAddWeight, L_SoTotalWeight, L_SoM_ExpeditionID,
                    L_SoExpService, L_SoExpCost, L_SoTotal, L_SoApproved, 
                    a.M_CustomerM_KelurahanID M_CustomerM_KelurahanID,
                    a.M_CustomerName M_CustomerName,
                    a.M_CustomerAddress M_CustomerAddress,
                    M_OrderStatusID, M_OrderStatusCode, M_OrderStatusName,
                    b.M_CustomerName ds_customer_name,
                    b.M_CustomerAddress ds_customer_address,
                    b.M_CustomerM_KelurahanID ds_customer_kelurahan_id
                FROM `{$this->table_name}`
                JOIN m_customer a ON L_SoM_CustomerID = a.M_CustomerID
                JOIN m_customerlevel ON a.M_CustomerM_CustomerLevelID = M_CustomerLevelID
                JOIN m_orderstatus ON L_SoM_OrderStatusID = M_OrderStatusID
                JOIN m_expedition ON L_SoM_ExpeditionID = M_ExpeditionID
                LEFT JOIN m_kelurahan ON M_KelurahanID = M_CustomerM_KelurahanID
                LEFT JOIN m_customer b ON L_SoDSM_CustomerID = b.M_CustomerID
                WHERE (`L_SoNumber` LIKE ? OR a.`M_CustomerName` LIKE ?)
                AND L_SoDate BETWEEN ? AND ?
                AND `L_SoIsActive` = 'Y'", [$d['search'], $d['search'], $d['sdate'], $d['edate']]);
        if ($r)
        {
            $r = $r->result_array();
            foreach ($r as $k => $v)
            {
                $ct = $this->db->query("SELECT fn_address_city(?) x", [$v['M_CustomerM_KelurahanID']])->row()->x;
                $ct = json_decode($ct);
                $r[$k]['city_name'] = $ct->city_name;
                $r[$k]['city_id'] = $ct->city_id;

                if ($v['L_SoIsDS'] == 'Y')
                {
                    $ct = $this->db->query("SELECT fn_address_city(?) x", [$v['ds_customer_kelurahan_id']])->row()->x;
                    $ct = json_decode($ct);
                    $r[$k]['ds_city_name'] = $ct->city_name;
                    $r[$k]['ds_city_id'] = $ct->city_id;
                }
            }
                
            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            JOIN m_customer ON L_SoM_CustomerID = M_CustomerID
            JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
            JOIN m_orderstatus ON L_SoM_OrderStatusID = M_OrderStatusID
            WHERE (`L_SoNumber` LIKE ? OR `M_CustomerName` LIKE ?)
            AND L_SoDate BETWEEN ? AND ?
                AND `L_SoIsActive` = 'Y'", [$d['search'], $d['search'], $d['sdate'], $d['edate']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }

    function approve($inp)
    {
        $r = $this->db->query("CALL sp_so_approve(?, ?, ?)", [json_encode($inp['header_data']), $inp['json_data'], $inp['uid']])
                    ->row();
        return $r;
    }

    function search_top_by_customer($d)
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT L_SoID, L_SoNumber, L_SoDate, L_SoIsDS, L_SoTotal
                FROM `{$this->table_name}`
                JOIN m_orderstatus ON L_SoM_OrderStatusID = M_OrderStatusID
                    AND M_OrderStatusCode <> 'SO.NEW'
                    AND M_OrderStatusCode <> 'SO.DRAFT'
                    AND M_OrderStatusCode <> 'SO.Approved'
                WHERE (`L_SoNumber` LIKE ?)
                AND L_SoM_CustomerID = ?
                AND `L_SoIsActive` = 'Y'
                LIMIT 10", [$d['search'], $d['customer_id']]);
        if ($r)
        {
            $r = $r->result_array();                
            $l['records'] = $r;
        }

        return $l;
    }
}
?>