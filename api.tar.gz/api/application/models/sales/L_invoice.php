<?php

class L_Invoice extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = 'l_invoice';
        $this->table_key = 'L_InvoiceID';
    }

    function search( $d )
    {
        $l = ['records'=>[], 'total'=>0];

        $r = $this->db->query(
                "SELECT *
                FROM `{$this->table_name}`
                JOIN l_so ON L_SoID = L_InvoiceL_SoID
                JOIN m_customer ON L_SoM_CustomerID = M_CustomerID
                JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
                JOIN m_orderstatus ON L_SoM_OrderStatusID = M_OrderStatusID 
                    AND M_OrderStatusCode = 'SO.Confirmed'
                LEFT JOIN m_kelurahan ON M_KelurahanID = M_CustomerM_KelurahanID
                WHERE (`L_SoNumber` LIKE ? OR `M_CustomerName` LIKE ?)
                AND L_SoDate BETWEEN ? AND ?
                AND `L_SoIsActive` = 'Y'", [$d['search'], $d['search'], $d['sdate'], $d['edate']]);
        if ($r)
        {
            $r = $r->result_array();
            foreach ($r as $k => $v)
            {
                $ct = $this->db->query("SELECT fn_address_city(?) x", [$v['M_CustomerM_KelurahanID']])->row()->x;
                $ct = json_decode($ct);
                $r[$k]['city_name'] = $ct->city_name;
                $r[$k]['city_id'] = $ct->city_id;
            }
                
            $l['records'] = $r;
        }

        $r = $this->db->query(
            "SELECT count(`{$this->table_key}`) n
            FROM `{$this->table_name}`
            JOIN l_so ON L_SoID = L_InvoiceL_SoID
            JOIN m_customer ON L_SoM_CustomerID = M_CustomerID
            JOIN m_customerlevel ON M_CustomerM_CustomerLevelID = M_CustomerLevelID
            JOIN m_orderstatus ON L_SoM_OrderStatusID = M_OrderStatusID
                AND M_OrderStatusCode = 'SO.Confirmed'
            WHERE (`L_SoNumber` LIKE ? OR `M_CustomerName` LIKE ?)
            AND L_SoDate BETWEEN ? AND ?
                AND `L_SoIsActive` = 'Y'", [$d['search'], $d['search'], $d['sdate'], $d['edate']]);
        if ($r)
        {
            $l['total'] = $r->row()->n;
        }
            
        return $l;
    }
}
?>