<?php

class S_system extends MY_Model
{
    function __construct()
    {
        parent::__construct();

        $this->table_name = 's_system';
        $this->primary_key = 'S_SystemID';
    }

    function get_default()
    {
        $r = $this->db->where('S_SystemIsActive', 'Y')
                    ->limit(1)
                    ->get($this->table_name)
                    ->row();
        return $r;
    }
}
?>
